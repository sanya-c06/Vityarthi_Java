package edu.ccrm.cli;

import edu.ccrm.config.AppConfig;
import edu.ccrm.service.StudentService;
import edu.ccrm.service.CourseService;
import edu.ccrm.service.EnrollmentService;
import edu.ccrm.service.TranscriptService;
import edu.ccrm.io.ImportExportService;
import edu.ccrm.io.BackupService;

import java.util.Scanner;

/**
 * Main entry point for the Campus Course & Records Manager (CCRM)
 * Demonstrates console-based menu system with switch statements
 */
public class Main {
    private static final Scanner scanner = new Scanner(System.in);
    private static final StudentService studentService = new StudentService();
    private static final CourseService courseService = new CourseService();
    private static final EnrollmentService enrollmentService = new EnrollmentService();
    private static final TranscriptService transcriptService = new TranscriptService();
    private static final ImportExportService importExportService = new ImportExportService();
    private static final BackupService backupService = new BackupService();

    public static void main(String[] args) {
        System.out.println("=== Campus Course & Records Manager (CCRM) ===");
        System.out.println();
        
        // Demonstrate Singleton pattern
        AppConfig config = AppConfig.getInstance();
        System.out.println("Configuration loaded from: " + config.getDataDirectory());
        System.out.println();
        
        boolean running = true;
        while (running) {
            displayMainMenu();
            int choice = getValidChoice(1, 8);
            
            switch (choice) {
                case 1:
                    manageStudents();
                    break;
                case 2:
                    manageCourses();
                    break;
                case 3:
                    manageEnrollments();
                    break;
                case 4:
                    manageGrades();
                    break;
                case 5:
                    importExportData();
                    break;
                case 6:
                    backupOperations();
                    break;
                case 7:
                    generateReports();
                    break;
                case 8:
                    running = false;
                    System.out.println("Thank you for using CCRM. Goodbye!");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
        
        scanner.close();
    }

    private static void displayMainMenu() {
        System.out.println("\n=== MAIN MENU ===");
        System.out.println("1. Manage Students");
        System.out.println("2. Manage Courses");
        System.out.println("3. Manage Enrollments");
        System.out.println("4. Manage Grades");
        System.out.println("5. Import/Export Data");
        System.out.println("6. Backup Operations");
        System.out.println("7. Generate Reports");
        System.out.println("8. Exit");
        System.out.print("Enter your choice (1-8): ");
    }

    private static void manageStudents() {
        boolean backToMain = false;
        
        while (!backToMain) {
            System.out.println("\n=== STUDENT MANAGEMENT ===");
            System.out.println("1. Add Student");
            System.out.println("2. List All Students");
            System.out.println("3. Update Student");
            System.out.println("4. View Student Profile");
            System.out.println("5. View Student Transcript");
            System.out.println("6. Deactivate Student");
            System.out.println("7. Back to Main Menu");
            System.out.print("Enter your choice (1-7): ");
            
            int choice = getValidChoice(1, 7);
            
            switch (choice) {
                case 1:
                    studentService.addStudent();
                    break;
                case 2:
                    studentService.listAllStudents();
                    break;
                case 3:
                    studentService.updateStudent();
                    break;
                case 4:
                    studentService.viewStudentProfile();
                    break;
                case 5:
                    transcriptService.generateTranscript();
                    break;
                case 6:
                    studentService.deactivateStudent();
                    break;
                case 7:
                    backToMain = true;
                    break;
            }
        }
    }

    private static void manageCourses() {
        boolean backToMain = false;
        
        while (!backToMain) {
            System.out.println("\n=== COURSE MANAGEMENT ===");
            System.out.println("1. Add Course");
            System.out.println("2. List All Courses");
            System.out.println("3. Update Course");
            System.out.println("4. Search Courses");
            System.out.println("5. Assign Instructor");
            System.out.println("6. Deactivate Course");
            System.out.println("7. Back to Main Menu");
            System.out.print("Enter your choice (1-7): ");
            
            int choice = getValidChoice(1, 7);
            
            switch (choice) {
                case 1:
                    courseService.addCourse();
                    break;
                case 2:
                    courseService.listAllCourses();
                    break;
                case 3:
                    courseService.updateCourse();
                    break;
                case 4:
                    courseService.searchCourses();
                    break;
                case 5:
                    courseService.assignInstructor();
                    break;
                case 6:
                    courseService.deactivateCourse();
                    break;
                case 7:
                    backToMain = true;
                    break;
            }
        }
    }

    private static void manageEnrollments() {
        boolean backToMain = false;
        
        while (!backToMain) {
            System.out.println("\n=== ENROLLMENT MANAGEMENT ===");
            System.out.println("1. Enroll Student");
            System.out.println("2. Unenroll Student");
            System.out.println("3. View Enrollments");
            System.out.println("4. Back to Main Menu");
            System.out.print("Enter your choice (1-4): ");
            
            int choice = getValidChoice(1, 4);
            
            switch (choice) {
                case 1:
                    enrollmentService.enrollStudent();
                    break;
                case 2:
                    enrollmentService.unenrollStudent();
                    break;
                case 3:
                    enrollmentService.viewEnrollments();
                    break;
                case 4:
                    backToMain = true;
                    break;
            }
        }
    }

    private static void manageGrades() {
        boolean backToMain = false;
        
        while (!backToMain) {
            System.out.println("\n=== GRADE MANAGEMENT ===");
            System.out.println("1. Record Grade");
            System.out.println("2. View Grades");
            System.out.println("3. Calculate GPA");
            System.out.println("4. Back to Main Menu");
            System.out.print("Enter your choice (1-4): ");
            
            int choice = getValidChoice(1, 4);
            
            switch (choice) {
                case 1:
                    transcriptService.recordGrade();
                    break;
                case 2:
                    transcriptService.viewGrades();
                    break;
                case 3:
                    transcriptService.calculateGPA();
                    break;
                case 4:
                    backToMain = true;
                    break;
            }
        }
    }

    private static void importExportData() {
        boolean backToMain = false;
        
        while (!backToMain) {
            System.out.println("\n=== IMPORT/EXPORT DATA ===");
            System.out.println("1. Import Students from CSV");
            System.out.println("2. Import Courses from CSV");
            System.out.println("3. Export Students to CSV");
            System.out.println("4. Export Courses to CSV");
            System.out.println("5. Export All Data");
            System.out.println("6. Back to Main Menu");
            System.out.print("Enter your choice (1-6): ");
            
            int choice = getValidChoice(1, 6);
            
            switch (choice) {
                case 1:
                    importExportService.importStudents();
                    break;
                case 2:
                    importExportService.importCourses();
                    break;
                case 3:
                    importExportService.exportStudents();
                    break;
                case 4:
                    importExportService.exportCourses();
                    break;
                case 5:
                    importExportService.exportAllData();
                    break;
                case 6:
                    backToMain = true;
                    break;
            }
        }
    }

    private static void backupOperations() {
        boolean backToMain = false;
        
        while (!backToMain) {
            System.out.println("\n=== BACKUP OPERATIONS ===");
            System.out.println("1. Create Backup");
            System.out.println("2. Show Backup Size (Recursive)");
            System.out.println("3. List Backup Files");
            System.out.println("4. Back to Main Menu");
            System.out.print("Enter your choice (1-4): ");
            
            int choice = getValidChoice(1, 4);
            
            switch (choice) {
                case 1:
                    backupService.createBackup();
                    break;
                case 2:
                    backupService.showBackupSize();
                    break;
                case 3:
                    backupService.listBackupFiles();
                    break;
                case 4:
                    backToMain = true;
                    break;
            }
        }
    }

    private static void generateReports() {
        boolean backToMain = false;
        
        while (!backToMain) {
            System.out.println("\n=== REPORTS ===");
            System.out.println("1. Top Students by GPA");
            System.out.println("2. GPA Distribution");
            System.out.println("3. Course Statistics");
            System.out.println("4. Enrollment Summary");
            System.out.println("5. Back to Main Menu");
            System.out.print("Enter your choice (1-5): ");
            
            int choice = getValidChoice(1, 5);
            
            switch (choice) {
                case 1:
                    transcriptService.generateTopStudentsReport();
                    break;
                case 2:
                    transcriptService.generateGPADistribution();
                    break;
                case 3:
                    courseService.generateCourseStatistics();
                    break;
                case 4:
                    enrollmentService.generateEnrollmentSummary();
                    break;
                case 5:
                    backToMain = true;
                    break;
            }
        }
    }

    private static int getValidChoice(int min, int max) {
        while (true) {
            try {
                int choice = Integer.parseInt(scanner.nextLine().trim());
                if (choice >= min && choice <= max) {
                    return choice;
                } else {
                    System.out.print("Please enter a number between " + min + " and " + max + ": ");
                }
            } catch (NumberFormatException e) {
                System.out.print("Please enter a valid number: ");
            }
        }
    }
}
