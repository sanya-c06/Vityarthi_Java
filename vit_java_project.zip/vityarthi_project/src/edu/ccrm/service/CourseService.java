package edu.ccrm.service;

import edu.ccrm.domain.Course;
import edu.ccrm.domain.Semester;
import edu.ccrm.domain.Searchable;

import java.util.*;
import java.util.stream.Collectors;

/**
 * Service class for course management
 * Demonstrates Searchable interface implementation and Stream API
 */
public class CourseService implements Searchable<Course> {
    private final Map<String, Course> courses = new HashMap<>();
    private final Scanner scanner = new Scanner(System.in);

    public CourseService() {
        initializeSampleData();
    }

    private void initializeSampleData() {
        // Using Builder pattern to create courses
        Course javaCourse = new Course.Builder()
                .setCode("CS101")
                .setTitle("Introduction to Programming")
                .setCredits(3)
                .setSemester(Semester.FALL)
                .setDepartment("Computer Science")
                .build();

        Course dataStructures = new Course.Builder()
                .setCode("CS201")
                .setTitle("Data Structures and Algorithms")
                .setCredits(4)
                .setSemester(Semester.SPRING)
                .setDepartment("Computer Science")
                .build();

        Course mathCourse = new Course.Builder()
                .setCode("MATH101")
                .setTitle("Calculus I")
                .setCredits(4)
                .setSemester(Semester.FALL)
                .setDepartment("Mathematics")
                .build();

        courses.put(javaCourse.getCode(), javaCourse);
        courses.put(dataStructures.getCode(), dataStructures);
        courses.put(mathCourse.getCode(), mathCourse);
    }

    public void addCourse() {
        System.out.println("\n=== ADD NEW COURSE ===");
        
        try {
            System.out.print("Enter course code: ");
            String code = scanner.nextLine().trim();
            
            if (courses.containsKey(code)) {
                System.out.println("Course with code " + code + " already exists!");
                return;
            }
            
            System.out.print("Enter course title: ");
            String title = scanner.nextLine().trim();
            
            System.out.print("Enter credits (1-6): ");
            int credits = Integer.parseInt(scanner.nextLine().trim());
            
            System.out.print("Enter instructor ID (optional): ");
            String instructorId = scanner.nextLine().trim();
            if (instructorId.isEmpty()) {
                instructorId = null;
            }
            
            System.out.println("Select semester:");
            Semester[] semesters = Semester.values();
            for (int i = 0; i < semesters.length; i++) {
                System.out.println((i + 1) + ". " + semesters[i]);
            }
            System.out.print("Enter choice (1-" + semesters.length + "): ");
            int semesterChoice = Integer.parseInt(scanner.nextLine().trim());
            Semester semester = semesters[semesterChoice - 1];
            
            System.out.print("Enter department: ");
            String department = scanner.nextLine().trim();
            
            Course course = new Course(code, title, credits, instructorId, semester, department);
            courses.put(code, course);
            
            System.out.println("Course added successfully!");
            System.out.println("Course Info: " + course);
            
        } catch (Exception e) {
            System.out.println("Error adding course: " + e.getMessage());
        }
    }

    public void listAllCourses() {
        System.out.println("\n=== ALL COURSES ===");
        
        if (courses.isEmpty()) {
            System.out.println("No courses found.");
            return;
        }
        
        courses.values().stream()
                .sorted(Comparator.comparing(Course::getCode))
                .forEach(course -> {
                    System.out.printf("Code: %s | Title: %s | Credits: %d | " +
                                    "Instructor: %s | Semester: %s | Department: %s | Active: %s%n",
                            course.getCode(), course.getTitle(), course.getCredits(),
                            course.getInstructorId() != null ? course.getInstructorId() : "Not Assigned",
                            course.getSemester(), course.getDepartment(), course.isActive());
                });
    }

    public void updateCourse() {
        System.out.println("\n=== UPDATE COURSE ===");
        
        System.out.print("Enter course code to update: ");
        String code = scanner.nextLine().trim();
        
        Course course = courses.get(code);
        if (course == null) {
            System.out.println("Course not found!");
            return;
        }
        
        try {
            System.out.println("Current course info: " + course);
            System.out.println("\nWhat would you like to update?");
            System.out.println("1. Title");
            System.out.println("2. Credits");
            System.out.println("3. Instructor");
            System.out.println("4. Semester");
            System.out.println("5. Department");
            System.out.println("6. Active Status");
            System.out.print("Enter choice (1-6): ");
            
            int choice = Integer.parseInt(scanner.nextLine().trim());
            
            switch (choice) {
                case 1:
                    System.out.print("Enter new title: ");
                    course.setTitle(scanner.nextLine().trim());
                    break;
                case 2:
                    System.out.print("Enter new credits: ");
                    course.setCredits(Integer.parseInt(scanner.nextLine().trim()));
                    break;
                case 3:
                    System.out.print("Enter new instructor ID: ");
                    String instructorId = scanner.nextLine().trim();
                    course.setInstructorId(instructorId.isEmpty() ? null : instructorId);
                    break;
                case 4:
                    System.out.println("Select new semester:");
                    Semester[] semesters = Semester.values();
                    for (int i = 0; i < semesters.length; i++) {
                        System.out.println((i + 1) + ". " + semesters[i]);
                    }
                    System.out.print("Enter choice (1-" + semesters.length + "): ");
                    int semesterChoice = Integer.parseInt(scanner.nextLine().trim());
                    if (semesterChoice >= 1 && semesterChoice <= semesters.length) {
                        course.setSemester(semesters[semesterChoice - 1]);
                    }
                    break;
                case 5:
                    System.out.print("Enter new department: ");
                    course.setDepartment(scanner.nextLine().trim());
                    break;
                case 6:
                    System.out.print("Set active status (true/false): ");
                    course.setActive(Boolean.parseBoolean(scanner.nextLine().trim()));
                    break;
                default:
                    System.out.println("Invalid choice!");
                    return;
            }
            
            System.out.println("Course updated successfully!");
            System.out.println("Updated info: " + course);
            
        } catch (Exception e) {
            System.out.println("Error updating course: " + e.getMessage());
        }
    }

    @Override
    public List<Course> search(java.util.function.Predicate<Course> predicate) {
        return courses.values().stream()
                .filter(predicate)
                .collect(Collectors.toList());
    }

    @Override
    public List<Course> searchByText(String query) {
        String lowerQuery = query.toLowerCase();
        return courses.values().stream()
                .filter(course -> 
                    course.getCode().toLowerCase().contains(lowerQuery) ||
                    course.getTitle().toLowerCase().contains(lowerQuery) ||
                    course.getDepartment().toLowerCase().contains(lowerQuery))
                .collect(Collectors.toList());
    }

    public void searchCourses() {
        System.out.println("\n=== SEARCH COURSES ===");
        System.out.println("1. Search by text");
        System.out.println("2. Search by instructor");
        System.out.println("3. Search by department");
        System.out.println("4. Search by semester");
        System.out.println("5. Search by credits");
        System.out.print("Enter choice (1-5): ");
        
        try {
            int choice = Integer.parseInt(scanner.nextLine().trim());
            
            switch (choice) {
                case 1:
                    System.out.print("Enter search text: ");
                    String query = scanner.nextLine().trim();
                    List<Course> textResults = searchByText(query);
                    displaySearchResults(textResults);
                    break;
                    
                case 2:
                    System.out.print("Enter instructor ID: ");
                    String instructorId = scanner.nextLine().trim();
                    List<Course> instructorResults = search(course -> 
                        instructorId.equals(course.getInstructorId()));
                    displaySearchResults(instructorResults);
                    break;
                    
                case 3:
                    System.out.print("Enter department: ");
                    String department = scanner.nextLine().trim();
                    List<Course> deptResults = search(course -> 
                        course.getDepartment().toLowerCase().contains(department.toLowerCase()));
                    displaySearchResults(deptResults);
                    break;
                    
                case 4:
                    System.out.println("Select semester:");
                    Semester[] semesters = Semester.values();
                    for (int i = 0; i < semesters.length; i++) {
                        System.out.println((i + 1) + ". " + semesters[i]);
                    }
                    System.out.print("Enter choice (1-" + semesters.length + "): ");
                    int semesterChoice = Integer.parseInt(scanner.nextLine().trim());
                    if (semesterChoice >= 1 && semesterChoice <= semesters.length) {
                        Semester semester = semesters[semesterChoice - 1];
                        List<Course> semesterResults = search(course -> 
                            course.getSemester() == semester);
                        displaySearchResults(semesterResults);
                    }
                    break;
                    
                case 5:
                    System.out.print("Enter minimum credits: ");
                    int minCredits = Integer.parseInt(scanner.nextLine().trim());
                    List<Course> creditsResults = search(course -> 
                        course.getCredits() >= minCredits);
                    displaySearchResults(creditsResults);
                    break;
                    
                default:
                    System.out.println("Invalid choice!");
            }
            
        } catch (Exception e) {
            System.out.println("Error searching courses: " + e.getMessage());
        }
    }

    private void displaySearchResults(List<Course> results) {
        if (results.isEmpty()) {
            System.out.println("No courses found matching the criteria.");
        } else {
            System.out.println("\nSearch Results (" + results.size() + " courses found):");
            results.forEach(course -> {
                System.out.printf("Code: %s | Title: %s | Credits: %d | " +
                                "Instructor: %s | Semester: %s | Department: %s%n",
                        course.getCode(), course.getTitle(), course.getCredits(),
                        course.getInstructorId() != null ? course.getInstructorId() : "Not Assigned",
                        course.getSemester(), course.getDepartment());
            });
        }
    }

    public void assignInstructor() {
        System.out.println("\n=== ASSIGN INSTRUCTOR ===");
        
        System.out.print("Enter course code: ");
        String code = scanner.nextLine().trim();
        
        Course course = courses.get(code);
        if (course == null) {
            System.out.println("Course not found!");
            return;
        }
        
        System.out.print("Enter instructor ID: ");
        String instructorId = scanner.nextLine().trim();
        
        course.setInstructorId(instructorId);
        
        System.out.println("Instructor assigned successfully!");
        System.out.println("Updated course: " + course);
    }

    public void deactivateCourse() {
        System.out.println("\n=== DEACTIVATE COURSE ===");
        
        System.out.print("Enter course code to deactivate: ");
        String code = scanner.nextLine().trim();
        
        Course course = courses.get(code);
        if (course == null) {
            System.out.println("Course not found!");
            return;
        }
        
        course.setActive(false);
        
        System.out.println("Course deactivated successfully!");
    }

    public Course getCourseByCode(String code) {
        return courses.get(code);
    }

    public List<Course> getAllCourses() {
        return new ArrayList<>(courses.values());
    }

    public List<Course> getActiveCourses() {
        return search(Course::isActive);
    }

    public void generateCourseStatistics() {
        System.out.println("\n=== COURSE STATISTICS ===");
        
        long totalCourses = courses.size();
        long activeCourses = courses.values().stream()
                .filter(Course::isActive)
                .count();
        
        Map<String, Long> coursesByDept = courses.values().stream()
                .collect(Collectors.groupingBy(Course::getDepartment, Collectors.counting()));
        
        Map<Semester, Long> coursesBySemester = courses.values().stream()
                .collect(Collectors.groupingBy(Course::getSemester, Collectors.counting()));
        
        System.out.println("Total Courses: " + totalCourses);
        System.out.println("Active Courses: " + activeCourses);
        System.out.println("\nCourses by Department:");
        coursesByDept.forEach((dept, count) -> 
            System.out.println("  " + dept + ": " + count));
        
        System.out.println("\nCourses by Semester:");
        coursesBySemester.forEach((semester, count) -> 
            System.out.println("  " + semester + ": " + count));
    }

    public boolean courseExists(String code) {
        return courses.containsKey(code);
    }
}
