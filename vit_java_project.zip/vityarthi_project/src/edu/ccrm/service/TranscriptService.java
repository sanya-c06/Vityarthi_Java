package edu.ccrm.service;

import edu.ccrm.domain.Grade;
import edu.ccrm.domain.Enrollment;

import java.util.*;
import java.util.stream.Collectors;

/**
 * Service class for transcript and grade management
 * Demonstrates polymorphism and complex calculations using Streams
 */
public class TranscriptService {
    private final EnrollmentService enrollmentService;
    private final StudentService studentService;
    private final CourseService courseService;
    private final Scanner scanner = new Scanner(System.in);

    public TranscriptService() {
        this.enrollmentService = new EnrollmentService();
        this.studentService = new StudentService();
        this.courseService = new CourseService();
    }

    public void recordGrade() {
        System.out.println("\n=== RECORD GRADE ===");
        
        try {
            System.out.print("Enter enrollment ID: ");
            String enrollmentId = scanner.nextLine().trim();
            
            Enrollment enrollment = enrollmentService.getEnrollmentById(enrollmentId);
            if (enrollment == null) {
                System.out.println("Enrollment not found!");
                return;
            }
            
            if (!enrollment.isActive()) {
                System.out.println("Cannot record grade for inactive enrollment!");
                return;
            }
            
            System.out.print("Enter percentage (0-100): ");
            double percentage = Double.parseDouble(scanner.nextLine().trim());
            
            if (percentage < 0 || percentage > 100) {
                System.out.println("Percentage must be between 0 and 100!");
                return;
            }
            
            Grade grade = Grade.fromPercentage(percentage);
            enrollment.recordGrade(grade);
            
            System.out.println("Grade recorded successfully!");
            System.out.printf("Student: %s | Course: %s | Grade: %s (%.1f%%)%n",
                    enrollment.getStudentId(), enrollment.getCourseCode(), grade, percentage);
            
        } catch (Exception e) {
            System.out.println("Error recording grade: " + e.getMessage());
        }
    }

    public void viewGrades() {
        System.out.println("\n=== VIEW GRADES ===");
        System.out.println("1. View grades by student");
        System.out.println("2. View grades by course");
        System.out.println("3. View all graded enrollments");
        System.out.print("Enter choice (1-3): ");
        
        try {
            int choice = Integer.parseInt(scanner.nextLine().trim());
            
            switch (choice) {
                case 1:
                    viewGradesByStudent();
                    break;
                case 2:
                    viewGradesByCourse();
                    break;
                case 3:
                    viewAllGrades();
                    break;
                default:
                    System.out.println("Invalid choice!");
            }
            
        } catch (Exception e) {
            System.out.println("Error viewing grades: " + e.getMessage());
        }
    }

    private void viewGradesByStudent() {
        System.out.print("Enter student ID: ");
        String studentId = scanner.nextLine().trim();
        
        List<Enrollment> studentEnrollments = enrollmentService.getEnrollmentsByStudent(studentId);
        List<Enrollment> gradedEnrollments = studentEnrollments.stream()
                .filter(Enrollment::hasGrade)
                .collect(Collectors.toList());
        
        if (gradedEnrollments.isEmpty()) {
            System.out.println("No grades found for this student.");
            return;
        }
        
        System.out.println("\nGrades for Student " + studentId + ":");
        System.out.println("Course\t\tSemester\tGrade\tGrade Point");
        System.out.println("------------------------------------------------");
        
        gradedEnrollments.forEach(enrollment -> {
            System.out.printf("%-12s\t%s %d\t%s\t%.1f%n",
                    enrollment.getCourseCode(),
                    enrollment.getSemester(),
                    enrollment.getYear(),
                    enrollment.getGrade().getLetter(),
                    enrollment.getGrade().getGradePoint());
        });
        
        // Calculate and display GPA
        double gpa = calculateGPA(studentEnrollments);
        System.out.printf("%nGPA: %.2f%n", gpa);
    }

    private void viewGradesByCourse() {
        System.out.print("Enter course code: ");
        String courseCode = scanner.nextLine().trim();
        
        List<Enrollment> courseEnrollments = enrollmentService.getActiveEnrollments().stream()
                .filter(enrollment -> enrollment.getCourseCode().equals(courseCode))
                .filter(Enrollment::hasGrade)
                .collect(Collectors.toList());
        
        if (courseEnrollments.isEmpty()) {
            System.out.println("No grades found for this course.");
            return;
        }
        
        System.out.println("\nGrades for Course " + courseCode + ":");
        System.out.println("Student\t\tSemester\tGrade\tGrade Point");
        System.out.println("------------------------------------------------");
        
        courseEnrollments.forEach(enrollment -> {
            System.out.printf("%-12s\t%s %d\t%s\t%.1f%n",
                    enrollment.getStudentId(),
                    enrollment.getSemester(),
                    enrollment.getYear(),
                    enrollment.getGrade().getLetter(),
                    enrollment.getGrade().getGradePoint());
        });
        
        // Calculate course statistics
        double averageGrade = courseEnrollments.stream()
                .mapToDouble(enrollment -> enrollment.getGrade().getGradePoint())
                .average()
                .orElse(0.0);
        
        System.out.printf("%nCourse Average: %.2f%n", averageGrade);
    }

    private void viewAllGrades() {
        List<Enrollment> allGradedEnrollments = enrollmentService.getActiveEnrollments().stream()
                .filter(Enrollment::hasGrade)
                .sorted(Comparator.comparing((Enrollment e) -> e.getStudentId())
                        .thenComparing(Enrollment::getCourseCode))
                .collect(Collectors.toList());
        
        if (allGradedEnrollments.isEmpty()) {
            System.out.println("No grades recorded yet.");
            return;
        }
        
        System.out.println("\n=== ALL GRADES ===");
        System.out.println("Student\t\tCourse\t\tSemester\tGrade\tGrade Point");
        System.out.println("--------------------------------------------------------");
        
        allGradedEnrollments.forEach(enrollment -> {
            System.out.printf("%-12s\t%-12s\t%s %d\t%s\t%.1f%n",
                    enrollment.getStudentId(),
                    enrollment.getCourseCode(),
                    enrollment.getSemester(),
                    enrollment.getYear(),
                    enrollment.getGrade().getLetter(),
                    enrollment.getGrade().getGradePoint());
        });
    }

    public void calculateGPA() {
        System.out.print("Enter student ID: ");
        String studentId = scanner.nextLine().trim();
        
        List<Enrollment> studentEnrollments = enrollmentService.getEnrollmentsByStudent(studentId);
        double gpa = calculateGPA(studentEnrollments);
        
        System.out.printf("GPA for Student %s: %.2f%n", studentId, gpa);
    }

    private double calculateGPA(List<Enrollment> enrollments) {
        List<Enrollment> gradedEnrollments = enrollments.stream()
                .filter(Enrollment::hasGrade)
                .collect(Collectors.toList());
        
        if (gradedEnrollments.isEmpty()) {
            return 0.0;
        }
        
        double totalGradePoints = 0.0;
        int totalCredits = 0;
        
        for (Enrollment enrollment : gradedEnrollments) {
            int credits = courseService.getCourseByCode(enrollment.getCourseCode()).getCredits();
            totalGradePoints += enrollment.getGrade().getGradePoint() * credits;
            totalCredits += credits;
        }
        
        return totalCredits > 0 ? totalGradePoints / totalCredits : 0.0;
    }

    public void generateTranscript() {
        System.out.println("\n=== GENERATE TRANSCRIPT ===");
        
        System.out.print("Enter student ID: ");
        String studentId = scanner.nextLine().trim();
        
        if (!studentService.studentExists(studentId)) {
            System.out.println("Student not found!");
            return;
        }
        
        // Demonstrate polymorphism - using toString() overrides
        System.out.println("\n" + "=".repeat(60));
        System.out.println("                    ACADEMIC TRANSCRIPT");
        System.out.println("=".repeat(60));
        
        // Student information using polymorphism
        System.out.println(studentService.getStudentById(studentId));
        System.out.println();
        
        List<Enrollment> studentEnrollments = enrollmentService.getEnrollmentsByStudent(studentId);
        
        if (studentEnrollments.isEmpty()) {
            System.out.println("No enrollments found for this student.");
            return;
        }
        
        // Group enrollments by semester and year
        Map<String, List<Enrollment>> enrollmentsByTerm = studentEnrollments.stream()
                .collect(Collectors.groupingBy(enrollment -> 
                    enrollment.getSemester() + " " + enrollment.getYear()));
        
        System.out.println("ACADEMIC RECORD:");
        System.out.println("-".repeat(60));
        
        double totalGradePoints = 0.0;
        int totalCredits = 0;
        
        for (Map.Entry<String, List<Enrollment>> entry : enrollmentsByTerm.entrySet()) {
            System.out.println("\nTerm: " + entry.getKey());
            System.out.println("Course Code\tCourse Title\t\tCredits\tGrade\tGrade Points");
            System.out.println("-".repeat(80));
            
            for (Enrollment enrollment : entry.getValue()) {
                String courseTitle = courseService.getCourseByCode(enrollment.getCourseCode()).getTitle();
                int credits = courseService.getCourseByCode(enrollment.getCourseCode()).getCredits();
                
                if (enrollment.hasGrade()) {
                    double gradePoints = enrollment.getGrade().getGradePoint() * credits;
                    totalGradePoints += gradePoints;
                    totalCredits += credits;
                    
                    System.out.printf("%-12s\t%-20s\t%d\t%s\t%.1f%n",
                            enrollment.getCourseCode(),
                            courseTitle.length() > 20 ? courseTitle.substring(0, 17) + "..." : courseTitle,
                            credits,
                            enrollment.getGrade().getLetter(),
                            gradePoints);
                } else {
                    System.out.printf("%-12s\t%-20s\t%d\t%s\t%.1f%n",
                            enrollment.getCourseCode(),
                            courseTitle.length() > 20 ? courseTitle.substring(0, 17) + "..." : courseTitle,
                            credits,
                            "IP",
                            0.0);
                }
            }
        }
        
        // Calculate and display overall GPA
        double overallGPA = totalCredits > 0 ? totalGradePoints / totalCredits : 0.0;
        
        System.out.println("\n" + "=".repeat(60));
        System.out.printf("Total Credits: %d%n", totalCredits);
        System.out.printf("Overall GPA: %.2f%n", overallGPA);
        System.out.println("=".repeat(60));
    }

    public void generateTopStudentsReport() {
        System.out.println("\n=== TOP STUDENTS BY GPA ===");
        
        Map<String, Double> studentGPAs = new HashMap<>();
        
        // Calculate GPA for each student
        studentService.getAllStudents().forEach(student -> {
            List<Enrollment> enrollments = enrollmentService.getEnrollmentsByStudent(student.getId());
            double gpa = calculateGPA(enrollments);
            if (gpa > 0) {
                studentGPAs.put(student.getId(), gpa);
            }
        });
        
        if (studentGPAs.isEmpty()) {
            System.out.println("No students with grades found.");
            return;
        }
        
        // Sort by GPA in descending order
        List<Map.Entry<String, Double>> sortedStudents = studentGPAs.entrySet().stream()
                .sorted(Map.Entry.<String, Double>comparingByValue().reversed())
                .collect(Collectors.toList());
        
        System.out.println("Rank\tStudent ID\tName\t\t\tGPA");
        System.out.println("-".repeat(60));
        
        int rank = 1;
        for (Map.Entry<String, Double> entry : sortedStudents) {
            String studentId = entry.getKey();
            double gpa = entry.getValue();
            String studentName = studentService.getStudentById(studentId).getFullName();
            
            System.out.printf("%d\t%-12s\t%-20s\t%.2f%n",
                    rank++, studentId, 
                    studentName.length() > 20 ? studentName.substring(0, 17) + "..." : studentName,
                    gpa);
            
            if (rank > 10) break; // Show top 10
        }
    }

    public void generateGPADistribution() {
        System.out.println("\n=== GPA DISTRIBUTION ===");
        
        Map<String, Double> studentGPAs = new HashMap<>();
        
        // Calculate GPA for each student
        studentService.getAllStudents().forEach(student -> {
            List<Enrollment> enrollments = enrollmentService.getEnrollmentsByStudent(student.getId());
            double gpa = calculateGPA(enrollments);
            if (gpa > 0) {
                studentGPAs.put(student.getId(), gpa);
            }
        });
        
        if (studentGPAs.isEmpty()) {
            System.out.println("No students with grades found.");
            return;
        }
        
        // Group GPAs into ranges
        Map<String, Long> gpaDistribution = studentGPAs.values().stream()
                .collect(Collectors.groupingBy(gpa -> {
                    if (gpa >= 9.0) return "9.0 - 10.0 (Excellent)";
                    else if (gpa >= 8.0) return "8.0 - 8.9 (Very Good)";
                    else if (gpa >= 7.0) return "7.0 - 7.9 (Good)";
                    else if (gpa >= 6.0) return "6.0 - 6.9 (Average)";
                    else if (gpa >= 5.0) return "5.0 - 5.9 (Below Average)";
                    else return "Below 5.0 (Poor)";
                }, Collectors.counting()));
        
        System.out.println("GPA Range\t\t\tCount\tPercentage");
        System.out.println("-".repeat(60));
        
        long totalStudents = studentGPAs.size();
        gpaDistribution.entrySet().stream()
                .sorted(Map.Entry.<String, Long>comparingByValue().reversed())
                .forEach(entry -> {
                    long count = entry.getValue();
                    double percentage = (count * 100.0) / totalStudents;
                    System.out.printf("%-30s\t%d\t%.1f%%%n", entry.getKey(), count, percentage);
                });
        
        // Calculate overall statistics
        double averageGPA = studentGPAs.values().stream()
                .mapToDouble(Double::doubleValue)
                .average()
                .orElse(0.0);
        
        System.out.println("\nOverall Statistics:");
        System.out.printf("Total Students: %d%n", totalStudents);
        System.out.printf("Average GPA: %.2f%n", averageGPA);
    }
}
