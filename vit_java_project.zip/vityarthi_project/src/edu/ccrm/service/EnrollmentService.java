package edu.ccrm.service;

import edu.ccrm.domain.Enrollment;
import edu.ccrm.domain.Semester;
import edu.ccrm.domain.Grade;
import edu.ccrm.config.AppConfig;

import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Service class for enrollment management
 * Demonstrates business logic validation and exception handling
 */
public class EnrollmentService {
    private final Map<String, Enrollment> enrollments = new HashMap<>();
    private final StudentService studentService;
    private final CourseService courseService;
    private final Scanner scanner = new Scanner(System.in);
    private int enrollmentIdCounter = 1;

    public EnrollmentService() {
        this.studentService = new StudentService();
        this.courseService = new CourseService();
        initializeSampleData();
    }

    private void initializeSampleData() {
        // Sample enrollments
        createEnrollment("ENR001", "STU001", "CS101", Semester.FALL, 2024);
        createEnrollment("ENR002", "STU001", "MATH101", Semester.FALL, 2024);
        createEnrollment("ENR003", "STU002", "CS101", Semester.FALL, 2024);
        createEnrollment("ENR004", "STU003", "CS201", Semester.SPRING, 2024);
    }

    private void createEnrollment(String id, String studentId, String courseCode, Semester semester, int year) {
        Enrollment enrollment = new Enrollment(id, studentId, courseCode, semester, year);
        enrollments.put(id, enrollment);
        
        // Also enroll student in the course
        if (studentService.studentExists(studentId)) {
            studentService.getStudentById(studentId).enrollInCourse(courseCode);
        }
    }

    public void enrollStudent() {
        System.out.println("\n=== ENROLL STUDENT ===");
        
        try {
            System.out.print("Enter student ID: ");
            String studentId = scanner.nextLine().trim();
            
            if (!studentService.studentExists(studentId)) {
                System.out.println("Student not found!");
                return;
            }
            
            System.out.print("Enter course code: ");
            String courseCode = scanner.nextLine().trim();
            
            if (!courseService.courseExists(courseCode)) {
                System.out.println("Course not found!");
                return;
            }
            
            System.out.println("Select semester:");
            Semester[] semesters = Semester.values();
            for (int i = 0; i < semesters.length; i++) {
                System.out.println((i + 1) + ". " + semesters[i]);
            }
            System.out.print("Enter choice (1-" + semesters.length + "): ");
            int semesterChoice = Integer.parseInt(scanner.nextLine().trim());
            Semester semester = semesters[semesterChoice - 1];
            
            System.out.print("Enter year: ");
            int year = Integer.parseInt(scanner.nextLine().trim());
            
            // Business logic validation
            validateEnrollment(studentId, courseCode, semester, year);
            
            String enrollmentId = "ENR" + String.format("%03d", enrollmentIdCounter++);
            Enrollment enrollment = new Enrollment(enrollmentId, studentId, courseCode, semester, year);
            enrollments.put(enrollmentId, enrollment);
            
            // Enroll student in the course
            studentService.getStudentById(studentId).enrollInCourse(courseCode);
            
            System.out.println("Student enrolled successfully!");
            System.out.println("Enrollment ID: " + enrollmentId);
            System.out.println("Enrollment Details: " + enrollment);
            
        } catch (EnrollmentException e) {
            System.out.println("Enrollment failed: " + e.getMessage());
        } catch (Exception e) {
            System.out.println("Error enrolling student: " + e.getMessage());
        }
    }

    private void validateEnrollment(String studentId, String courseCode, Semester semester, int year) 
            throws EnrollmentException {
        
        // Check if already enrolled
        boolean alreadyEnrolled = enrollments.values().stream()
                .anyMatch(enrollment -> 
                    enrollment.getStudentId().equals(studentId) &&
                    enrollment.getCourseCode().equals(courseCode) &&
                    enrollment.getSemester() == semester &&
                    enrollment.getYear() == year &&
                    enrollment.isActive());
        
        if (alreadyEnrolled) {
            throw new DuplicateEnrollmentException("Student is already enrolled in this course for the given semester and year");
        }
        
        // Check credit limit
        int currentCredits = getCurrentSemesterCredits(studentId, semester, year);
        int courseCredits = courseService.getCourseByCode(courseCode).getCredits();
        int maxCredits = AppConfig.getInstance().getMaxCreditsPerSemester();
        
        if (currentCredits + courseCredits > maxCredits) {
            throw new MaxCreditLimitExceededException(
                String.format("Credit limit exceeded. Current: %d, Course: %d, Max: %d", 
                            currentCredits, courseCredits, maxCredits));
        }
        
        // Check if student is active
        if (!studentService.getStudentById(studentId).isActive()) {
            throw new EnrollmentException("Only active students can enroll in courses");
        }
        
        // Check if course is active
        if (!courseService.getCourseByCode(courseCode).isActive()) {
            throw new EnrollmentException("Only active courses can be enrolled in");
        }
    }

    private int getCurrentSemesterCredits(String studentId, Semester semester, int year) {
        return enrollments.values().stream()
                .filter(enrollment -> 
                    enrollment.getStudentId().equals(studentId) &&
                    enrollment.getSemester() == semester &&
                    enrollment.getYear() == year &&
                    enrollment.isActive())
                .mapToInt(enrollment -> 
                    courseService.getCourseByCode(enrollment.getCourseCode()).getCredits())
                .sum();
    }

    public void unenrollStudent() {
        System.out.println("\n=== UNENROLL STUDENT ===");
        
        System.out.print("Enter enrollment ID: ");
        String enrollmentId = scanner.nextLine().trim();
        
        Enrollment enrollment = enrollments.get(enrollmentId);
        if (enrollment == null) {
            System.out.println("Enrollment not found!");
            return;
        }
        
        if (!enrollment.isActive()) {
            System.out.println("Enrollment is already inactive!");
            return;
        }
        
        enrollment.deactivate();
        
        // Remove from student's enrolled courses
        if (studentService.studentExists(enrollment.getStudentId())) {
            studentService.getStudentById(enrollment.getStudentId())
                    .unenrollFromCourse(enrollment.getCourseCode());
        }
        
        System.out.println("Student unenrolled successfully!");
    }

    public void viewEnrollments() {
        System.out.println("\n=== VIEW ENROLLMENTS ===");
        System.out.println("1. View all enrollments");
        System.out.println("2. View enrollments by student");
        System.out.println("3. View enrollments by course");
        System.out.println("4. View enrollments by semester");
        System.out.print("Enter choice (1-4): ");
        
        try {
            int choice = Integer.parseInt(scanner.nextLine().trim());
            
            switch (choice) {
                case 1:
                    displayAllEnrollments();
                    break;
                case 2:
                    viewEnrollmentsByStudent();
                    break;
                case 3:
                    viewEnrollmentsByCourse();
                    break;
                case 4:
                    viewEnrollmentsBySemester();
                    break;
                default:
                    System.out.println("Invalid choice!");
            }
            
        } catch (Exception e) {
            System.out.println("Error viewing enrollments: " + e.getMessage());
        }
    }

    private void displayAllEnrollments() {
        System.out.println("\n=== ALL ENROLLMENTS ===");
        
        if (enrollments.isEmpty()) {
            System.out.println("No enrollments found.");
            return;
        }
        
        enrollments.values().stream()
                .sorted(Comparator.comparing(Enrollment::getEnrollmentDate).reversed())
                .forEach(enrollment -> {
                    System.out.printf("ID: %s | Student: %s | Course: %s | " +
                                    "Semester: %s %d | Grade: %s | Active: %s%n",
                            enrollment.getId(), enrollment.getStudentId(), enrollment.getCourseCode(),
                            enrollment.getSemester(), enrollment.getYear(),
                            enrollment.getGrade() != null ? enrollment.getGrade() : "Not Graded",
                            enrollment.isActive());
                });
    }

    private void viewEnrollmentsByStudent() {
        System.out.print("Enter student ID: ");
        String studentId = scanner.nextLine().trim();
        
        List<Enrollment> studentEnrollments = enrollments.values().stream()
                .filter(enrollment -> enrollment.getStudentId().equals(studentId))
                .collect(Collectors.toList());
        
        if (studentEnrollments.isEmpty()) {
            System.out.println("No enrollments found for this student.");
        } else {
            System.out.println("\nEnrollments for Student " + studentId + ":");
            studentEnrollments.forEach(enrollment -> {
                System.out.printf("Course: %s | Semester: %s %d | Grade: %s | Active: %s%n",
                        enrollment.getCourseCode(), enrollment.getSemester(), enrollment.getYear(),
                        enrollment.getGrade() != null ? enrollment.getGrade() : "Not Graded",
                        enrollment.isActive());
            });
        }
    }

    private void viewEnrollmentsByCourse() {
        System.out.print("Enter course code: ");
        String courseCode = scanner.nextLine().trim();
        
        List<Enrollment> courseEnrollments = enrollments.values().stream()
                .filter(enrollment -> enrollment.getCourseCode().equals(courseCode))
                .collect(Collectors.toList());
        
        if (courseEnrollments.isEmpty()) {
            System.out.println("No enrollments found for this course.");
        } else {
            System.out.println("\nEnrollments for Course " + courseCode + ":");
            courseEnrollments.forEach(enrollment -> {
                System.out.printf("Student: %s | Semester: %s %d | Grade: %s | Active: %s%n",
                        enrollment.getStudentId(), enrollment.getSemester(), enrollment.getYear(),
                        enrollment.getGrade() != null ? enrollment.getGrade() : "Not Graded",
                        enrollment.isActive());
            });
        }
    }

    private void viewEnrollmentsBySemester() {
        System.out.println("Select semester:");
        Semester[] semesters = Semester.values();
        for (int i = 0; i < semesters.length; i++) {
            System.out.println((i + 1) + ". " + semesters[i]);
        }
        System.out.print("Enter choice (1-" + semesters.length + "): ");
        
        int semesterChoice = Integer.parseInt(scanner.nextLine().trim());
        Semester semester = semesters[semesterChoice - 1];
        
        System.out.print("Enter year: ");
        int year = Integer.parseInt(scanner.nextLine().trim());
        
        List<Enrollment> semesterEnrollments = enrollments.values().stream()
                .filter(enrollment -> 
                    enrollment.getSemester() == semester && 
                    enrollment.getYear() == year)
                .collect(Collectors.toList());
        
        if (semesterEnrollments.isEmpty()) {
            System.out.println("No enrollments found for " + semester + " " + year + ".");
        } else {
            System.out.println("\nEnrollments for " + semester + " " + year + ":");
            semesterEnrollments.forEach(enrollment -> {
                System.out.printf("Student: %s | Course: %s | Grade: %s | Active: %s%n",
                        enrollment.getStudentId(), enrollment.getCourseCode(),
                        enrollment.getGrade() != null ? enrollment.getGrade() : "Not Graded",
                        enrollment.isActive());
            });
        }
    }

    public void generateEnrollmentSummary() {
        System.out.println("\n=== ENROLLMENT SUMMARY ===");
        
        long totalEnrollments = enrollments.size();
        long activeEnrollments = enrollments.values().stream()
                .filter(Enrollment::isActive)
                .count();
        
        Map<String, Long> enrollmentsByStudent = enrollments.values().stream()
                .filter(Enrollment::isActive)
                .collect(Collectors.groupingBy(Enrollment::getStudentId, Collectors.counting()));
        
        Map<String, Long> enrollmentsByCourse = enrollments.values().stream()
                .filter(Enrollment::isActive)
                .collect(Collectors.groupingBy(Enrollment::getCourseCode, Collectors.counting()));
        
        System.out.println("Total Enrollments: " + totalEnrollments);
        System.out.println("Active Enrollments: " + activeEnrollments);
        
        System.out.println("\nTop Enrolled Students:");
        enrollmentsByStudent.entrySet().stream()
                .sorted(Map.Entry.<String, Long>comparingByValue().reversed())
                .limit(5)
                .forEach(entry -> 
                    System.out.println("  " + entry.getKey() + ": " + entry.getValue() + " courses"));
        
        System.out.println("\nMost Popular Courses:");
        enrollmentsByCourse.entrySet().stream()
                .sorted(Map.Entry.<String, Long>comparingByValue().reversed())
                .limit(5)
                .forEach(entry -> 
                    System.out.println("  " + entry.getKey() + ": " + entry.getValue() + " students"));
    }

    public Enrollment getEnrollmentById(String id) {
        return enrollments.get(id);
    }

    public List<Enrollment> getEnrollmentsByStudent(String studentId) {
        return enrollments.values().stream()
                .filter(enrollment -> enrollment.getStudentId().equals(studentId))
                .collect(Collectors.toList());
    }

    public List<Enrollment> getActiveEnrollments() {
        return enrollments.values().stream()
                .filter(Enrollment::isActive)
                .collect(Collectors.toList());
    }

    public boolean enrollmentExists(String id) {
        return enrollments.containsKey(id);
    }

    // Custom exception classes
    public static class EnrollmentException extends Exception {
        public EnrollmentException(String message) {
            super(message);
        }
    }

    public static class DuplicateEnrollmentException extends EnrollmentException {
        public DuplicateEnrollmentException(String message) {
            super(message);
        }
    }

    public static class MaxCreditLimitExceededException extends EnrollmentException {
        public MaxCreditLimitExceededException(String message) {
            super(message);
        }
    }
}
