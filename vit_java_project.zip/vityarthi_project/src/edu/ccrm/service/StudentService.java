package edu.ccrm.service;

import edu.ccrm.domain.Student;
import edu.ccrm.domain.Student.StudentStatus;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Service class for student management
 * Demonstrates service layer pattern and Stream API usage
 */
public class StudentService {
    private final Map<String, Student> students = new HashMap<>();
    private final Scanner scanner = new Scanner(System.in);
    private int studentIdCounter = 1;

    public StudentService() {
        // Initialize with some sample data
        initializeSampleData();
    }

    private void initializeSampleData() {
        addStudentInternal("STU001", "John Doe", "john.doe@university.edu", "REG001");
        addStudentInternal("STU002", "Jane Smith", "jane.smith@university.edu", "REG002");
        addStudentInternal("STU003", "Bob Johnson", "bob.johnson@university.edu", "REG003");
    }

    private void addStudentInternal(String id, String fullName, String email, String regNo) {
        Student student = new Student(id, regNo, fullName, email);
        students.put(id, student);
    }

    public void addStudent() {
        System.out.println("\n=== ADD NEW STUDENT ===");
        
        try {
            System.out.print("Enter student ID: ");
            String id = scanner.nextLine().trim();
            
            if (students.containsKey(id)) {
                System.out.println("Student with ID " + id + " already exists!");
                return;
            }
            
            System.out.print("Enter registration number: ");
            String regNo = scanner.nextLine().trim();
            
            System.out.print("Enter full name: ");
            String fullName = scanner.nextLine().trim();
            
            System.out.print("Enter email: ");
            String email = scanner.nextLine().trim();
            
            Student student = new Student(id, regNo, fullName, email);
            students.put(id, student);
            
            System.out.println("Student added successfully!");
            System.out.println("Student Info: " + student.getDisplayInfo());
            
        } catch (Exception e) {
            System.out.println("Error adding student: " + e.getMessage());
        }
    }

    public void listAllStudents() {
        System.out.println("\n=== ALL STUDENTS ===");
        
        if (students.isEmpty()) {
            System.out.println("No students found.");
            return;
        }
        
        // Using Stream API to format and display students
        students.values().stream()
                .sorted(Comparator.comparing(Student::getFullName))
                .forEach(student -> {
                    System.out.printf("ID: %s | Name: %s | Reg No: %s | Email: %s | Status: %s%n",
                            student.getId(), student.getFullName(), student.getRegNo(),
                            student.getEmail(), student.getStatus());
                });
    }

    public void updateStudent() {
        System.out.println("\n=== UPDATE STUDENT ===");
        
        System.out.print("Enter student ID to update: ");
        String id = scanner.nextLine().trim();
        
        Student student = students.get(id);
        if (student == null) {
            System.out.println("Student not found!");
            return;
        }
        
        try {
            System.out.println("Current student info: " + student);
            System.out.println("\nWhat would you like to update?");
            System.out.println("1. Full Name");
            System.out.println("2. Email");
            System.out.println("3. Registration Number");
            System.out.println("4. Status");
            System.out.print("Enter choice (1-4): ");
            
            int choice = Integer.parseInt(scanner.nextLine().trim());
            
            switch (choice) {
                case 1:
                    System.out.print("Enter new full name: ");
                    student.setFullName(scanner.nextLine().trim());
                    break;
                case 2:
                    System.out.print("Enter new email: ");
                    student.setEmail(scanner.nextLine().trim());
                    break;
                case 3:
                    System.out.print("Enter new registration number: ");
                    student.setRegNo(scanner.nextLine().trim());
                    break;
                case 4:
                    System.out.println("Select new status:");
                    StudentStatus[] statuses = StudentStatus.values();
                    for (int i = 0; i < statuses.length; i++) {
                        System.out.println((i + 1) + ". " + statuses[i]);
                    }
                    System.out.print("Enter choice (1-" + statuses.length + "): ");
                    int statusChoice = Integer.parseInt(scanner.nextLine().trim());
                    if (statusChoice >= 1 && statusChoice <= statuses.length) {
                        student.setStatus(statuses[statusChoice - 1]);
                    }
                    break;
                default:
                    System.out.println("Invalid choice!");
                    return;
            }
            
            System.out.println("Student updated successfully!");
            System.out.println("Updated info: " + student);
            
        } catch (Exception e) {
            System.out.println("Error updating student: " + e.getMessage());
        }
    }

    public void viewStudentProfile() {
        System.out.println("\n=== STUDENT PROFILE ===");
        
        System.out.print("Enter student ID: ");
        String id = scanner.nextLine().trim();
        
        Student student = students.get(id);
        if (student == null) {
            System.out.println("Student not found!");
            return;
        }
        
        System.out.println("\n=== STUDENT PROFILE ===");
        System.out.println("ID: " + student.getId());
        System.out.println("Registration Number: " + student.getRegNo());
        System.out.println("Full Name: " + student.getFullName());
        System.out.println("Email: " + student.getEmail());
        System.out.println("Status: " + student.getStatus());
        System.out.println("Enrolled Courses: " + student.getEnrollmentCount());
        System.out.println("Created Date: " + student.getCreatedDate());
        System.out.println("Last Modified: " + student.getLastModified());
        System.out.println("Creation Info: " + student.getCreationInfo());
        
        if (!student.getEnrolledCourses().isEmpty()) {
            System.out.println("\nEnrolled Courses:");
            student.getEnrolledCourses().forEach(course -> 
                System.out.println("  - " + course));
        }
    }

    public void deactivateStudent() {
        System.out.println("\n=== DEACTIVATE STUDENT ===");
        
        System.out.print("Enter student ID to deactivate: ");
        String id = scanner.nextLine().trim();
        
        Student student = students.get(id);
        if (student == null) {
            System.out.println("Student not found!");
            return;
        }
        
        student.setActive(false);
        student.setStatus(StudentStatus.INACTIVE);
        
        System.out.println("Student deactivated successfully!");
    }

    public Student getStudentById(String id) {
        return students.get(id);
    }

    public List<Student> getAllStudents() {
        return new ArrayList<>(students.values());
    }

    public List<Student> getActiveStudents() {
        return students.values().stream()
                .filter(Student::isActive)
                .collect(Collectors.toList());
    }

    public List<Student> searchStudentsByName(String name) {
        return students.values().stream()
                .filter(student -> student.getFullName().toLowerCase()
                        .contains(name.toLowerCase()))
                .collect(Collectors.toList());
    }

    public List<Student> searchStudentsByEmail(String email) {
        return students.values().stream()
                .filter(student -> student.getEmail().toLowerCase()
                        .contains(email.toLowerCase()))
                .collect(Collectors.toList());
    }

    public boolean studentExists(String id) {
        return students.containsKey(id);
    }

    public int getTotalStudentCount() {
        return students.size();
    }

    public int getActiveStudentCount() {
        return (int) students.values().stream()
                .filter(Student::isActive)
                .count();
    }
}
