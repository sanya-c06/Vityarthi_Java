package edu.ccrm.io;

import edu.ccrm.config.AppConfig;
import edu.ccrm.service.StudentService;
import edu.ccrm.service.CourseService;
import edu.ccrm.service.EnrollmentService;

import java.io.IOException;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 * Service for backup operations using NIO.2
 * Demonstrates NIO.2 file operations, recursion, and backup functionality
 */
public class BackupService {
    private final AppConfig config;
    private final StudentService studentService;
    private final CourseService courseService;
    private final EnrollmentService enrollmentService;
    private final Scanner scanner = new Scanner(System.in);

    public BackupService() {
        this.config = AppConfig.getInstance();
        this.studentService = new StudentService();
        this.courseService = new CourseService();
        this.enrollmentService = new EnrollmentService();
    }

    public void createBackup() {
        System.out.println("\n=== CREATE BACKUP ===");
        
        try {
            // Create timestamped backup directory
            String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss"));
            Path backupDir = config.getBackupDirectory().resolve("backup_" + timestamp);
            
            // Create backup directory
            Files.createDirectories(backupDir);
            
            System.out.println("Creating backup in: " + backupDir);
            
            // Export current data to backup directory
            exportDataToBackup(backupDir);
            
            System.out.println("Backup created successfully!");
            System.out.println("Backup location: " + backupDir);
            
        } catch (IOException e) {
            System.out.println("Error creating backup: " + e.getMessage());
        }
    }

    private void exportDataToBackup(Path backupDir) throws IOException {
        // Export students
        Path studentsFile = backupDir.resolve("students_backup.csv");
        String studentsContent = generateStudentsBackupContent();
        Files.write(studentsFile, studentsContent.getBytes(), StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
        
        // Export courses
        Path coursesFile = backupDir.resolve("courses_backup.csv");
        String coursesContent = generateCoursesBackupContent();
        Files.write(coursesFile, coursesContent.getBytes(), StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
        
        // Export enrollments
        Path enrollmentsFile = backupDir.resolve("enrollments_backup.csv");
        String enrollmentsContent = generateEnrollmentsBackupContent();
        Files.write(enrollmentsFile, enrollmentsContent.getBytes(), StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
        
        // Create backup info file
        Path infoFile = backupDir.resolve("backup_info.txt");
        String infoContent = generateBackupInfo();
        Files.write(infoFile, infoContent.getBytes(), StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
        
        System.out.println("Files backed up:");
        System.out.println("  - " + studentsFile.getFileName());
        System.out.println("  - " + coursesFile.getFileName());
        System.out.println("  - " + enrollmentsFile.getFileName());
        System.out.println("  - " + infoFile.getFileName());
    }

    private String generateStudentsBackupContent() {
        StringBuilder content = new StringBuilder();
        content.append("ID,Registration Number,Full Name,Email,Status,Created Date,Last Modified\n");
        
        studentService.getAllStudents().forEach(student -> {
            content.append(String.format("%s,%s,%s,%s,%s,%s,%s%n",
                    student.getId(),
                    student.getRegNo(),
                    student.getFullName(),
                    student.getEmail(),
                    student.getStatus(),
                    student.getCreatedDate().format(DateTimeFormatter.ofPattern(config.getDateFormat())),
                    student.getLastModified().format(DateTimeFormatter.ofPattern(config.getDateFormat()))));
        });
        
        return content.toString();
    }

    private String generateCoursesBackupContent() {
        StringBuilder content = new StringBuilder();
        content.append("Code,Title,Credits,Instructor ID,Semester,Department,Active,Created Date,Last Modified\n");
        
        courseService.getAllCourses().forEach(course -> {
            content.append(String.format("%s,%s,%d,%s,%s,%s,%s,%s,%s%n",
                    course.getCode(),
                    course.getTitle(),
                    course.getCredits(),
                    course.getInstructorId() != null ? course.getInstructorId() : "",
                    course.getSemester(),
                    course.getDepartment(),
                    course.isActive(),
                    course.getCreatedDate().format(DateTimeFormatter.ofPattern(config.getDateFormat())),
                    course.getLastModified().format(DateTimeFormatter.ofPattern(config.getDateFormat()))));
        });
        
        return content.toString();
    }

    private String generateEnrollmentsBackupContent() {
        StringBuilder content = new StringBuilder();
        content.append("ID,Student ID,Course Code,Semester,Year,Grade,Active,Enrollment Date\n");
        
        enrollmentService.getActiveEnrollments().forEach(enrollment -> {
            content.append(String.format("%s,%s,%s,%s,%d,%s,%s,%s%n",
                    enrollment.getId(),
                    enrollment.getStudentId(),
                    enrollment.getCourseCode(),
                    enrollment.getSemester(),
                    enrollment.getYear(),
                    enrollment.getGrade() != null ? enrollment.getGrade().getLetter() : "",
                    enrollment.isActive(),
                    enrollment.getEnrollmentDate().format(DateTimeFormatter.ofPattern(config.getDateFormat()))));
        });
        
        return content.toString();
    }

    private String generateBackupInfo() {
        StringBuilder info = new StringBuilder();
        info.append("Campus Course & Records Manager - Backup Information\n");
        info.append("=" .repeat(50)).append("\n");
        info.append("Backup Date: ").append(LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))).append("\n");
        info.append("Total Students: ").append(studentService.getTotalStudentCount()).append("\n");
        info.append("Active Students: ").append(studentService.getActiveStudentCount()).append("\n");
        info.append("Total Courses: ").append(courseService.getAllCourses().size()).append("\n");
        info.append("Active Courses: ").append(courseService.getActiveCourses().size()).append("\n");
        info.append("Total Enrollments: ").append(enrollmentService.getActiveEnrollments().size()).append("\n");
        info.append("\nThis backup contains all current data from the CCRM system.\n");
        info.append("Use the import functionality to restore data from this backup.\n");
        
        return info.toString();
    }

    public void showBackupSize() {
        System.out.println("\n=== BACKUP DIRECTORY SIZE (RECURSIVE) ===");
        
        try {
            Path backupDir = config.getBackupDirectory();
            
            if (!Files.exists(backupDir)) {
                System.out.println("Backup directory does not exist: " + backupDir);
                return;
            }
            
            // Use recursive utility to calculate total size
            long totalSize = calculateDirectorySizeRecursively(backupDir);
            
            System.out.println("Backup directory: " + backupDir);
            System.out.println("Total size: " + formatFileSize(totalSize));
            
            // Also show size by depth
            showDirectorySizeByDepth(backupDir);
            
        } catch (IOException e) {
            System.out.println("Error calculating backup size: " + e.getMessage());
        }
    }

    /**
     * Recursive utility to calculate directory size
     * Demonstrates recursion as required
     */
    private long calculateDirectorySizeRecursively(Path directory) throws IOException {
        final long[] totalSize = {0};
        
        Files.walkFileTree(directory, new SimpleFileVisitor<Path>() {
            @Override
            public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) throws IOException {
                totalSize[0] += attrs.size();
                return FileVisitResult.CONTINUE;
            }
            
            @Override
            public FileVisitResult visitFileFailed(Path file, IOException exc) throws IOException {
                System.err.println("Failed to access file: " + file + " - " + exc.getMessage());
                return FileVisitResult.CONTINUE;
            }
        });
        
        return totalSize[0];
    }

    /**
     * Show directory size by depth
     * Demonstrates recursive file traversal and depth-based processing
     */
    private void showDirectorySizeByDepth(Path directory) throws IOException {
        System.out.println("\nSize by depth:");
        System.out.println("Depth\tDirectory\t\t\tSize");
        System.out.println("-".repeat(60));
        
        List<Path> directoriesByDepth = new ArrayList<>();
        
        // Collect directories by depth using recursion
        collectDirectoriesByDepth(directory, 0, directoriesByDepth);
        
        // Calculate and display size for each depth level
        for (Path dir : directoriesByDepth) {
            try {
                long size = calculateDirectorySizeRecursively(dir);
                int depth = directory.relativize(dir).getNameCount();
                String relativePath = directory.relativize(dir).toString();
                if (relativePath.isEmpty()) relativePath = ".";
                
                System.out.printf("%d\t%-30s\t%s%n", depth, relativePath, formatFileSize(size));
            } catch (IOException e) {
                System.err.println("Error calculating size for: " + dir);
            }
        }
    }

    /**
     * Recursive utility to collect directories by depth
     */
    private void collectDirectoriesByDepth(Path directory, int currentDepth, List<Path> directoriesByDepth) throws IOException {
        directoriesByDepth.add(directory);
        
        try (DirectoryStream<Path> stream = Files.newDirectoryStream(directory, Files::isDirectory)) {
            for (Path subdir : stream) {
                collectDirectoriesByDepth(subdir, currentDepth + 1, directoriesByDepth);
            }
        }
    }

    private String formatFileSize(long bytes) {
        if (bytes < 1024) return bytes + " B";
        if (bytes < 1024 * 1024) return String.format("%.2f KB", bytes / 1024.0);
        if (bytes < 1024 * 1024 * 1024) return String.format("%.2f MB", bytes / (1024.0 * 1024.0));
        return String.format("%.2f GB", bytes / (1024.0 * 1024.0 * 1024.0));
    }

    public void listBackupFiles() {
        System.out.println("\n=== LIST BACKUP FILES ===");
        
        try {
            Path backupDir = config.getBackupDirectory();
            
            if (!Files.exists(backupDir)) {
                System.out.println("Backup directory does not exist: " + backupDir);
                return;
            }
            
            System.out.println("Backup directory: " + backupDir);
            System.out.println("\nBackup folders:");
            System.out.println("Name\t\t\t\tCreated\t\t\tSize");
            System.out.println("-".repeat(80));
            
            // List backup directories
            try (DirectoryStream<Path> stream = Files.newDirectoryStream(backupDir, Files::isDirectory)) {
                for (Path backupFolder : stream) {
                    String folderName = backupFolder.getFileName().toString();
                    String createdDate = getFolderCreationDate(backupFolder);
                    long size = calculateDirectorySizeRecursively(backupFolder);
                    
                    System.out.printf("%-30s\t%s\t%s%n", 
                            folderName.length() > 30 ? folderName.substring(0, 27) + "..." : folderName,
                            createdDate,
                            formatFileSize(size));
                }
            }
            
            // List individual backup files
            System.out.println("\nBackup files:");
            System.out.println("Name\t\t\t\tSize\t\t\tModified");
            System.out.println("-".repeat(80));
            
            try (DirectoryStream<Path> stream = Files.newDirectoryStream(backupDir, Files::isRegularFile)) {
                for (Path backupFile : stream) {
                    String fileName = backupFile.getFileName().toString();
                    long size = Files.size(backupFile);
                    String modifiedDate = Files.getLastModifiedTime(backupFile)
                            .toString().substring(0, 19).replace('T', ' ');
                    
                    System.out.printf("%-30s\t%s\t\t%s%n",
                            fileName.length() > 30 ? fileName.substring(0, 27) + "..." : fileName,
                            formatFileSize(size),
                            modifiedDate);
                }
            }
            
        } catch (IOException e) {
            System.out.println("Error listing backup files: " + e.getMessage());
        }
    }

    private String getFolderCreationDate(Path folder) {
        try {
            return Files.getLastModifiedTime(folder)
                    .toString().substring(0, 19).replace('T', ' ');
        } catch (IOException e) {
            return "Unknown";
        }
    }

    /**
     * Demonstrate NIO.2 file operations: copy, move, delete
     */
    public void demonstrateFileOperations() {
        System.out.println("\n=== DEMONSTRATE FILE OPERATIONS ===");
        
        try {
            Path sourceDir = config.getDataDirectory();
            Path backupDir = config.getBackupDirectory();
            
            // Create a test file
            Path testFile = sourceDir.resolve("test_operation.txt");
            Files.write(testFile, "This is a test file for demonstrating NIO.2 operations.".getBytes());
            
            // Copy operation
            Path copiedFile = backupDir.resolve("test_copy.txt");
            Files.copy(testFile, copiedFile, StandardCopyOption.REPLACE_EXISTING);
            System.out.println("File copied: " + testFile + " -> " + copiedFile);
            
            // Move operation
            Path movedFile = backupDir.resolve("test_moved.txt");
            Files.move(copiedFile, movedFile, StandardCopyOption.REPLACE_EXISTING);
            System.out.println("File moved: " + copiedFile + " -> " + movedFile);
            
            // Delete operations
            Files.deleteIfExists(movedFile);
            System.out.println("File deleted: " + movedFile);
            
            Files.deleteIfExists(testFile);
            System.out.println("File deleted: " + testFile);
            
            System.out.println("File operations demonstration completed successfully!");
            
        } catch (IOException e) {
            System.out.println("Error demonstrating file operations: " + e.getMessage());
        }
    }
}
