package edu.ccrm.io;

import edu.ccrm.config.AppConfig;
import edu.ccrm.domain.Course;
import edu.ccrm.domain.Enrollment;
import edu.ccrm.domain.Semester;
import edu.ccrm.domain.Student;
import edu.ccrm.service.CourseService;
import edu.ccrm.service.EnrollmentService;
import edu.ccrm.service.StudentService;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

/**
 * Service for importing and exporting data using NIO.2
 * Demonstrates NIO.2 APIs, Stream processing, and file I/O operations
 */
public class ImportExportService {
    private final StudentService studentService;
    private final CourseService courseService;
    private final EnrollmentService enrollmentService;
    private final AppConfig config;
    private final Scanner scanner = new Scanner(System.in);

    public ImportExportService() {
        this.studentService = new StudentService();
        this.courseService = new CourseService();
        this.enrollmentService = new EnrollmentService();
        this.config = AppConfig.getInstance();
    }

    public void importStudents() {
        System.out.println("\n=== IMPORT STUDENTS FROM CSV ===");
        // FIX: Added try block to handle potential IOExceptions
        try {
            // Directly set the file path without asking the user.
            String filePath = "C:\\Users\\megha\\OneDrive\\Desktop\\vityarthi_project\\data\\students.csv";
            
            Path path = Path.of(filePath);
            
            if (!Files.exists(path)) {
                System.out.println("File does not exist: " + path);
                System.out.println("Creating sample file...");
                createSampleStudentsFile(path);
                return;
            }
            
            // Read and process file using NIO.2 and Streams
            List<String> lines = Files.readAllLines(path);
            
            if (lines.isEmpty()) {
                System.out.println("File is empty!");
                return;
            }
            
            // Skip header line and process data
            lines.stream()
                 .skip(1) // Skip header
                 .filter(line -> !line.trim().isEmpty()) // Filter empty lines
                .forEach(this::importStudentFromLine);
            
            System.out.println("Students imported successfully!");
            System.out.println("Total students: " + studentService.getTotalStudentCount());
            
        } catch (IOException e) {
            System.out.println("Error importing students: " + e.getMessage());
        }
    }

    private void importStudentFromLine(String line) {
        try {
            String[] fields = line.split(config.getCsvDelimiter());
            
            if (fields.length < 4) {
                System.out.println("Invalid line format: " + line);
                return;
            }
            
            String id = fields[0].trim();
            String regNo = fields[1].trim();
            String fullName = fields[2].trim();
            String email = fields[3].trim();
            
            if (!studentService.studentExists(id)) {
                Student student = new Student(id, regNo, fullName, email);
                // Note: In a real application, we'd add to the service's collection
                System.out.println("Imported student: " + student.getDisplayInfo());
            } else {
                System.out.println("Student already exists: " + id);
            }
            
        } catch (Exception e) {
            System.out.println("Error processing line: " + line + " - " + e.getMessage());
        }
    }

    public void importCourses() {
        System.out.println("\n=== IMPORT COURSES FROM CSV ===");
        
        try {
            System.out.print("Enter CSV file path (or press Enter for default: data/courses.csv): ");
            String filePath = scanner.nextLine().trim();
            
            if (filePath.isEmpty()) {
                filePath = "data/courses.csv";
            }
            
            Path path = Path.of(filePath);
            
            if (!Files.exists(path)) {
                System.out.println("File does not exist: " + path);
                System.out.println("Creating sample file...");
                createSampleCoursesFile(path);
                return;
            }
            
            List<String> lines = Files.readAllLines(path);
            
            if (lines.isEmpty()) {
                System.out.println("File is empty!");
                return;
            }
            
            lines.stream()
                .skip(1) // Skip header
                .filter(line -> !line.trim().isEmpty())
                .forEach(this::importCourseFromLine);
            
            System.out.println("Courses imported successfully!");
            
        } catch (IOException e) {
            System.out.println("Error importing courses: " + e.getMessage());
        }
    }

    private void importCourseFromLine(String line) {
        try {
            String[] fields = line.split(config.getCsvDelimiter());
            
            if (fields.length < 6) {
                System.out.println("Invalid line format: " + line);
                return;
            }
            
            String code = fields[0].trim();
            String title = fields[1].trim();
            int credits = Integer.parseInt(fields[2].trim());
            String instructorId = fields[3].trim().isEmpty() ? null : fields[3].trim();
            Semester semester = Semester.valueOf(fields[4].trim().toUpperCase());
            String department = fields[5].trim();
            
            if (!courseService.courseExists(code)) {
                Course course = new Course(code, title, credits, instructorId, semester, department);
                System.out.println("Imported course: " + course);
            } else {
                System.out.println("Course already exists: " + code);
            }
            
        } catch (Exception e) {
            System.out.println("Error processing line: " + line + " - " + e.getMessage());
        }
    }

    public void exportStudents() {
        System.out.println("\n=== EXPORT STUDENTS TO CSV ===");
        
        try {
            System.out.print("Enter output file path (or press Enter for default: data/students_export.csv): ");
            String filePath = scanner.nextLine().trim();
            
            if (filePath.isEmpty()) {
                filePath = "data/students_export.csv";
            }
            
            Path path = Path.of(filePath);
            
            // Ensure directory exists
            Files.createDirectories(path.getParent());
            
            // Create CSV content using Streams
            StringBuilder csvContent = new StringBuilder();
            csvContent.append("ID,Registration Number,Full Name,Email,Status,Created Date\n");
            
            studentService.getAllStudents().stream()
                .sorted(Comparator.comparing(Student::getId))
                .forEach(student -> {
                    csvContent.append(String.format("%s,%s,%s,%s,%s,%s%n",
                        student.getId(),
                        student.getRegNo(),
                        student.getFullName(),
                        student.getEmail(),
                        student.getStatus(),
                        student.getCreatedDate().format(DateTimeFormatter.ofPattern(config.getDateFormat()))));
                });
            
            // Write to file using NIO.2
            Files.write(path, csvContent.toString().getBytes(), StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
            
            System.out.println("Students exported successfully to: " + path);
            System.out.println("Total students exported: " + studentService.getTotalStudentCount());
            
        } catch (IOException e) {
            System.out.println("Error exporting students: " + e.getMessage());
        }
    }

    public void exportCourses() {
        System.out.println("\n=== EXPORT COURSES TO CSV ===");
        
        try {
            System.out.print("Enter output file path (or press Enter for default: data/courses_export.csv): ");
            String filePath = scanner.nextLine().trim();
            
            if (filePath.isEmpty()) {
                filePath = "data/courses_export.csv";
            }
            
            Path path = Path.of(filePath);
            
            Files.createDirectories(path.getParent());
            
            StringBuilder csvContent = new StringBuilder();
            csvContent.append("Code,Title,Credits,Instructor ID,Semester,Department,Active,Created Date\n");
            
            courseService.getAllCourses().stream()
                .sorted(Comparator.comparing(Course::getCode))
                .forEach(course -> {
                    csvContent.append(String.format("%s,%s,%d,%s,%s,%s,%s,%s%n",
                        course.getCode(),
                        course.getTitle(),
                        course.getCredits(),
                        course.getInstructorId() != null ? course.getInstructorId() : "",
                        course.getSemester(),
                        course.getDepartment(),
                        course.isActive(),
                        course.getCreatedDate().format(DateTimeFormatter.ofPattern(config.getDateFormat()))));
                });
            
            Files.write(path, csvContent.toString().getBytes(), StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
            
            System.out.println("Courses exported successfully to: " + path);
            
        } catch (IOException e) {
            System.out.println("Error exporting courses: " + e.getMessage());
        }
    }

    public void exportAllData() {
        System.out.println("\n=== EXPORT ALL DATA ===");
        
        try {
            String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss"));
            String basePath = "data/exports/export_" + timestamp;
            
            // Export students
            Path studentsPath = Path.of(basePath + "_students.csv");
            Files.createDirectories(studentsPath.getParent());
            
            StringBuilder studentsContent = new StringBuilder();
            studentsContent.append("ID,Registration Number,Full Name,Email,Status,Created Date,Enrolled Courses Count\n");
            
            studentService.getAllStudents().stream()
                .sorted(Comparator.comparing(Student::getId))
                .forEach(student -> {
                    studentsContent.append(String.format("%s,%s,%s,%s,%s,%s,%d%n",
                        student.getId(),
                        student.getRegNo(),
                        student.getFullName(),
                        student.getEmail(),
                        student.getStatus(),
                        student.getCreatedDate().format(DateTimeFormatter.ofPattern(config.getDateFormat())),
                        student.getEnrollmentCount()));
                });
            
            Files.write(studentsPath, studentsContent.toString().getBytes(), StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
            
            // Export courses
            Path coursesPath = Path.of(basePath + "_courses.csv");
            
            StringBuilder coursesContent = new StringBuilder();
            coursesContent.append("Code,Title,Credits,Instructor ID,Semester,Department,Active,Created Date\n");
            
            courseService.getAllCourses().stream()
                .sorted(Comparator.comparing(Course::getCode))
                .forEach(course -> {
                    coursesContent.append(String.format("%s,%s,%d,%s,%s,%s,%s,%s%n",
                        course.getCode(),
                        course.getTitle(),
                        course.getCredits(),
                        course.getInstructorId() != null ? course.getInstructorId() : "",
                        course.getSemester(),
                        course.getDepartment(),
                        course.isActive(),
                        course.getCreatedDate().format(DateTimeFormatter.ofPattern(config.getDateFormat()))));
                });
            
            Files.write(coursesPath, coursesContent.toString().getBytes(), StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
            
            // Export enrollments
            Path enrollmentsPath = Path.of(basePath + "_enrollments.csv");
            
            StringBuilder enrollmentsContent = new StringBuilder();
            enrollmentsContent.append("ID,Student ID,Course Code,Semester,Year,Grade,Active,Enrollment Date\n");
            
            enrollmentService.getActiveEnrollments().stream()
                .sorted(Comparator.comparing(Enrollment::getId))
                .forEach(enrollment -> {
                    enrollmentsContent.append(String.format("%s,%s,%s,%s,%d,%s,%s,%s%n",
                        enrollment.getId(),
                        enrollment.getStudentId(),
                        enrollment.getCourseCode(),
                        enrollment.getSemester(),
                        enrollment.getYear(),
                        enrollment.getGrade() != null ? enrollment.getGrade().getLetter() : "",
                        enrollment.isActive(),
                        enrollment.getEnrollmentDate().format(DateTimeFormatter.ofPattern(config.getDateFormat()))));
                });
            
            Files.write(enrollmentsPath, enrollmentsContent.toString().getBytes(), StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
            
            System.out.println("All data exported successfully!");
            System.out.println("Export location: " + basePath);
            System.out.println("Files created:");
            System.out.println("  - " + studentsPath.getFileName());
            System.out.println("  - " + coursesPath.getFileName());
            System.out.println("  - " + enrollmentsPath.getFileName());
            
        } catch (IOException e) {
            System.out.println("Error exporting all data: " + e.getMessage());
        }
    }

    private void createSampleStudentsFile(Path path) {
        try {
            Files.createDirectories(path.getParent());
            
            String sampleContent = "ID,Registration Number,Full Name,Email\n" +
                "STU001,REG001,John Doe,john.doe@university.edu\n" +
                "STU002,REG002,Jane Smith,jane.smith@university.edu\n" +
                "STU003,REG003,Bob Johnson,bob.johnson@university.edu\n" +
                "STU004,REG004,Alice Brown,alice.brown@university.edu\n" +
                "STU005,REG005,Charlie Wilson,charlie.wilson@university.edu\n";
            
            Files.write(path, sampleContent.getBytes(), StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
            System.out.println("Sample students file created: " + path);
            System.out.println("You can now import students from this file.");
            
        } catch (IOException e) {
            System.out.println("Error creating sample file: " + e.getMessage());
        }
    }

    private void createSampleCoursesFile(Path path) {
        try {
            Files.createDirectories(path.getParent());
            
            String sampleContent = "Code,Title,Credits,Instructor ID,Semester,Department\n" +
                "CS101,Introduction to Programming,3,INST001,FALL,Computer Science\n" +
                "CS201,Data Structures and Algorithms,4,INST002,SPRING,Computer Science\n" +
                "MATH101,Calculus I,4,INST003,FALL,Mathematics\n" +
                "ENG101,English Composition,3,INST004,FALL,English\n" +
                "PHYS101,Physics I,4,INST005,FALL,Physics\n";
            
            Files.write(path, sampleContent.getBytes(), StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
            System.out.println("Sample courses file created: " + path);
            System.out.println("You can now import courses from this file.");
            
        } catch (IOException e) {
            System.out.println("Error creating sample file: " + e.getMessage());
        }
    }
}