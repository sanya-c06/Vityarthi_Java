package edu.ccrm.util;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.regex.Pattern;

/**
 * Utility class for validation operations
 * Demonstrates static methods and utility patterns
 */
public class ValidationUtil {
    
    // Regex patterns for validation
    private static final Pattern EMAIL_PATTERN = Pattern.compile(
            "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$");
    private static final Pattern STUDENT_ID_PATTERN = Pattern.compile("^STU\\d{3}$");
    private static final Pattern COURSE_CODE_PATTERN = Pattern.compile("^[A-Z]{2,4}\\d{3}$");
    private static final Pattern REGISTRATION_PATTERN = Pattern.compile("^REG\\d{3}$");
    
    // Private constructor to prevent instantiation
    private ValidationUtil() {
        throw new UnsupportedOperationException("Utility class cannot be instantiated");
    }
    
    /**
     * Validate email format
     * @param email email to validate
     * @return true if valid
     */
    public static boolean isValidEmail(String email) {
        if (email == null || email.trim().isEmpty()) {
            return false;
        }
        return EMAIL_PATTERN.matcher(email.trim()).matches();
    }
    
    /**
     * Validate student ID format
     * @param studentId student ID to validate
     * @return true if valid
     */
    public static boolean isValidStudentId(String studentId) {
        if (studentId == null || studentId.trim().isEmpty()) {
            return false;
        }
        return STUDENT_ID_PATTERN.matcher(studentId.trim()).matches();
    }
    
    /**
     * Validate course code format
     * @param courseCode course code to validate
     * @return true if valid
     */
    public static boolean isValidCourseCode(String courseCode) {
        if (courseCode == null || courseCode.trim().isEmpty()) {
            return false;
        }
        return COURSE_CODE_PATTERN.matcher(courseCode.trim()).matches();
    }
    
    /**
     * Validate registration number format
     * @param regNo registration number to validate
     * @return true if valid
     */
    public static boolean isValidRegistrationNumber(String regNo) {
        if (regNo == null || regNo.trim().isEmpty()) {
            return false;
        }
        return REGISTRATION_PATTERN.matcher(regNo.trim()).matches();
    }
    
    /**
     * Validate name format (letters, spaces, hyphens, apostrophes)
     * @param name name to validate
     * @return true if valid
     */
    public static boolean isValidName(String name) {
        if (name == null || name.trim().isEmpty()) {
            return false;
        }
        String trimmedName = name.trim();
        return trimmedName.length() >= 2 && 
               trimmedName.length() <= 50 &&
               trimmedName.matches("^[a-zA-Z\\s\\-'']+$");
    }
    
    /**
     * Validate credits (1-6)
     * @param credits credits to validate
     * @return true if valid
     */
    public static boolean isValidCredits(int credits) {
        return credits >= 1 && credits <= 6;
    }
    
    /**
     * Validate year (2020-2030)
     * @param year year to validate
     * @return true if valid
     */
    public static boolean isValidYear(int year) {
        return year >= 2020 && year <= 2030;
    }
    
    /**
     * Validate date format
     * @param dateString date string to validate
     * @param pattern date pattern to use
     * @return true if valid
     */
    public static boolean isValidDate(String dateString, String pattern) {
        if (dateString == null || dateString.trim().isEmpty()) {
            return false;
        }
        
        try {
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern(pattern);
            LocalDate.parse(dateString.trim(), formatter);
            return true;
        } catch (DateTimeParseException e) {
            return false;
        }
    }
    
    /**
     * Validate percentage (0-100)
     * @param percentage percentage to validate
     * @return true if valid
     */
    public static boolean isValidPercentage(double percentage) {
        return percentage >= 0.0 && percentage <= 100.0;
    }
    
    /**
     * Sanitize string input (remove extra whitespace, trim)
     * @param input input string to sanitize
     * @return sanitized string
     */
    public static String sanitizeString(String input) {
        if (input == null) {
            return "";
        }
        return input.trim().replaceAll("\\s+", " ");
    }
    
    /**
     * Validate that string is not null or empty
     * @param input input to validate
     * @return true if not null and not empty
     */
    public static boolean isNotNullOrEmpty(String input) {
        return input != null && !input.trim().isEmpty();
    }
    
    /**
     * Validate that string length is within bounds
     * @param input input to validate
     * @param minLength minimum length
     * @param maxLength maximum length
     * @return true if length is within bounds
     */
    public static boolean isValidLength(String input, int minLength, int maxLength) {
        if (input == null) {
            return false;
        }
        int length = input.trim().length();
        return length >= minLength && length <= maxLength;
    }
    
    /**
     * Validate numeric range
     * @param value value to validate
     * @param min minimum value
     * @param max maximum value
     * @return true if within range
     */
    public static boolean isInRange(double value, double min, double max) {
        return value >= min && value <= max;
    }
    
    /**
     * Validate that object is not null
     * @param obj object to validate
     * @return true if not null
     */
    public static boolean isNotNull(Object obj) {
        return obj != null;
    }
    
    /**
     * Get validation error message for email
     * @param email email that failed validation
     * @return error message
     */
    public static String getEmailValidationMessage(String email) {
        if (email == null || email.trim().isEmpty()) {
            return "Email cannot be empty";
        }
        if (!isValidEmail(email)) {
            return "Email format is invalid. Expected format: user@domain.com";
        }
        return null;
    }
    
    /**
     * Get validation error message for student ID
     * @param studentId student ID that failed validation
     * @return error message
     */
    public static String getStudentIdValidationMessage(String studentId) {
        if (studentId == null || studentId.trim().isEmpty()) {
            return "Student ID cannot be empty";
        }
        if (!isValidStudentId(studentId)) {
            return "Student ID format is invalid. Expected format: STU### (e.g., STU001)";
        }
        return null;
    }
    
    /**
     * Get validation error message for course code
     * @param courseCode course code that failed validation
     * @return error message
     */
    public static String getCourseCodeValidationMessage(String courseCode) {
        if (courseCode == null || courseCode.trim().isEmpty()) {
            return "Course code cannot be empty";
        }
        if (!isValidCourseCode(courseCode)) {
            return "Course code format is invalid. Expected format: XXXX### (e.g., CS101)";
        }
        return null;
    }
}
