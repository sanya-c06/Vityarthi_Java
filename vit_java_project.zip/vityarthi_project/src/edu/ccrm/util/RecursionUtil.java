package edu.ccrm.util;

import java.io.IOException;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;

/**
 * Utility class demonstrating recursion
 * Shows various recursive algorithms and patterns
 */
public class RecursionUtil {
    
    // Private constructor to prevent instantiation
    private RecursionUtil() {
        throw new UnsupportedOperationException("Utility class cannot be instantiated");
    }
    
    /**
     * Calculate factorial using recursion
     * Demonstrates basic recursion with termination condition
     * @param n number to calculate factorial for
     * @return factorial of n
     */
    public static long factorial(int n) {
        // Base case - termination condition
        if (n <= 1) {
            return 1;
        }
        
        // Recursive case
        return n * factorial(n - 1);
    }
    
    /**
     * Calculate factorial with validation and assertion
     * Demonstrates assertions for invariants
     * @param n number to calculate factorial for
     * @return factorial of n
     */
    public static long factorialWithAssertion(int n) {
        // Precondition assertion
        assert n >= 0 : "Factorial is not defined for negative numbers: " + n;
        
        // Base case
        if (n <= 1) {
            return 1;
        }
        
        // Recursive case
        long result = n * factorialWithAssertion(n - 1);
        
        // Postcondition assertion
        assert result > 0 : "Factorial result should be positive: " + result;
        
        return result;
    }
    
    /**
     * Calculate Fibonacci number using recursion
     * Demonstrates recursion with multiple base cases
     * @param n position in Fibonacci sequence
     * @return Fibonacci number at position n
     */
    public static long fibonacci(int n) {
        // Base cases
        if (n <= 0) {
            return 0;
        }
        if (n == 1) {
            return 1;
        }
        
        // Recursive case
        return fibonacci(n - 1) + fibonacci(n - 2);
    }
    
    /**
     * Optimized Fibonacci with memoization
     * Demonstrates recursion with caching to avoid redundant calculations
     * @param n position in Fibonacci sequence
     * @return Fibonacci number at position n
     */
    public static long fibonacciMemoized(int n, long[] memo) {
        // Base cases
        if (n <= 0) {
            return 0;
        }
        if (n == 1) {
            return 1;
        }
        
        // Check if already calculated
        if (memo[n] != 0) {
            return memo[n];
        }
        
        // Calculate and store result
        memo[n] = fibonacciMemoized(n - 1, memo) + fibonacciMemoized(n - 2, memo);
        return memo[n];
    }
    
    /**
     * Reverse a string using recursion
     * Demonstrates recursion with string manipulation
     * @param str string to reverse
     * @return reversed string
     */
    public static String reverseString(String str) {
        // Base case
        if (str == null || str.length() <= 1) {
            return str;
        }
        
        // Recursive case
        return str.charAt(str.length() - 1) + reverseString(str.substring(0, str.length() - 1));
    }
    
    /**
     * Check if string is palindrome using recursion
     * Demonstrates recursion with string comparison
     * @param str string to check
     * @return true if palindrome
     */
    public static boolean isPalindrome(String str) {
        if (str == null || str.length() <= 1) {
            return true;
        }
        
        // Convert to lowercase and remove non-alphanumeric characters
        str = str.toLowerCase().replaceAll("[^a-z0-9]", "");
        
        // Base case
        if (str.length() <= 1) {
            return true;
        }
        
        // Check first and last characters
        if (str.charAt(0) != str.charAt(str.length() - 1)) {
            return false;
        }
        
        // Recursive case - check middle substring
        return isPalindrome(str.substring(1, str.length() - 1));
    }
    
    /**
     * Calculate sum of array elements using recursion
     * Demonstrates recursion with arrays
     * @param array array of integers
     * @param index current index
     * @return sum of elements from index to end
     */
    public static int sumArray(int[] array, int index) {
        // Base case
        if (index >= array.length) {
            return 0;
        }
        
        // Recursive case
        return array[index] + sumArray(array, index + 1);
    }
    
    /**
     * Find maximum element in array using recursion
     * Demonstrates recursion with comparison logic
     * @param array array of integers
     * @param index current index
     * @return maximum element from index to end
     */
    public static int findMax(int[] array, int index) {
        // Base case
        if (index == array.length - 1) {
            return array[index];
        }
        
        // Recursive case
        int maxOfRest = findMax(array, index + 1);
        return Math.max(array[index], maxOfRest);
    }
    
    /**
     * Count files in directory recursively
     * Demonstrates recursion with file system traversal
     * @param directory directory to count files in
     * @return total number of files
     */
    public static int countFilesRecursively(Path directory) {
        int count = 0;
        
        try {
            if (!Files.exists(directory) || !Files.isDirectory(directory)) {
                return 0;
            }
            
            try (DirectoryStream<Path> stream = Files.newDirectoryStream(directory)) {
                for (Path path : stream) {
                    if (Files.isDirectory(path)) {
                        // Recursive case - count files in subdirectory
                        count += countFilesRecursively(path);
                    } else if (Files.isRegularFile(path)) {
                        // Base case - found a file
                        count++;
                    }
                }
            }
            
        } catch (IOException e) {
            System.err.println("Error counting files in " + directory + ": " + e.getMessage());
        }
        
        return count;
    }
    
    /**
     * Calculate total size of directory recursively
     * Demonstrates recursion with file size calculation
     * @param directory directory to calculate size for
     * @return total size in bytes
     */
    public static long calculateDirectorySizeRecursively(Path directory) {
        long totalSize = 0;
        
        try {
            if (!Files.exists(directory) || !Files.isDirectory(directory)) {
                return 0;
            }
            
            try (DirectoryStream<Path> stream = Files.newDirectoryStream(directory)) {
                for (Path path : stream) {
                    if (Files.isDirectory(path)) {
                        // Recursive case - calculate size of subdirectory
                        totalSize += calculateDirectorySizeRecursively(path);
                    } else if (Files.isRegularFile(path)) {
                        // Base case - add file size
                        totalSize += Files.size(path);
                    }
                }
            }
            
        } catch (IOException e) {
            System.err.println("Error calculating size of " + directory + ": " + e.getMessage());
        }
        
        return totalSize;
    }
    
    /**
     * Find files matching predicate recursively
     * Demonstrates recursion with functional programming
     * @param directory directory to search in
     * @param predicate condition for file matching
     * @return list of matching files
     */
    public static List<Path> findFilesRecursively(Path directory, Predicate<Path> predicate) {
        List<Path> matchingFiles = new ArrayList<>();
        
        try {
            if (!Files.exists(directory) || !Files.isDirectory(directory)) {
                return matchingFiles;
            }
            
            try (DirectoryStream<Path> stream = Files.newDirectoryStream(directory)) {
                for (Path path : stream) {
                    if (Files.isDirectory(path)) {
                        // Recursive case - search in subdirectory
                        matchingFiles.addAll(findFilesRecursively(path, predicate));
                    } else if (Files.isRegularFile(path) && predicate.test(path)) {
                        // Base case - found matching file
                        matchingFiles.add(path);
                    }
                }
            }
            
        } catch (IOException e) {
            System.err.println("Error searching files in " + directory + ": " + e.getMessage());
        }
        
        return matchingFiles;
    }
    
    /**
     * Apply function to all files recursively
     * Demonstrates recursion with function application
     * @param directory directory to process
     * @param function function to apply to each file
     * @return list of results
     */
    public static <T> List<T> processFilesRecursively(Path directory, Function<Path, T> function) {
        List<T> results = new ArrayList<>();
        
        try {
            if (!Files.exists(directory) || !Files.isDirectory(directory)) {
                return results;
            }
            
            try (DirectoryStream<Path> stream = Files.newDirectoryStream(directory)) {
                for (Path path : stream) {
                    if (Files.isDirectory(path)) {
                        // Recursive case - process subdirectory
                        results.addAll(processFilesRecursively(path, function));
                    } else if (Files.isRegularFile(path)) {
                        // Base case - apply function to file
                        T result = function.apply(path);
                        if (result != null) {
                            results.add(result);
                        }
                    }
                }
            }
            
        } catch (IOException e) {
            System.err.println("Error processing files in " + directory + ": " + e.getMessage());
        }
        
        return results;
    }
    
    /**
     * Print directory tree recursively
     * Demonstrates recursion with indentation for tree structure
     * @param directory directory to print
     * @param depth current depth level
     * @param maxDepth maximum depth to traverse
     */
    public static void printDirectoryTree(Path directory, int depth, int maxDepth) {
        // Base case - maximum depth reached
        if (depth > maxDepth) {
            return;
        }
        
        try {
            if (!Files.exists(directory) || !Files.isDirectory(directory)) {
                return;
            }
            
            // Print current directory with indentation
            String indent = "  ".repeat(depth);
            System.out.println(indent + "📁 " + directory.getFileName());
            
            try (DirectoryStream<Path> stream = Files.newDirectoryStream(directory)) {
                for (Path path : stream) {
                    if (Files.isDirectory(path)) {
                        // Recursive case - print subdirectory
                        printDirectoryTree(path, depth + 1, maxDepth);
                    } else {
                        // Base case - print file
                        System.out.println(indent + "  📄 " + path.getFileName());
                    }
                }
            }
            
        } catch (IOException e) {
            System.err.println("Error printing directory tree: " + e.getMessage());
        }
    }
    
    /**
     * Demonstrate various recursive algorithms
     * Shows different types of recursion patterns
     */
    public static void demonstrateRecursion() {
        System.out.println("\n=== RECURSION DEMONSTRATION ===");
        
        // Factorial
        System.out.println("Factorial of 5: " + factorial(5));
        System.out.println("Factorial of 10: " + factorial(10));
        
        // Fibonacci
        System.out.println("Fibonacci sequence (first 10 numbers):");
        for (int i = 0; i < 10; i++) {
            System.out.print(fibonacci(i) + " ");
        }
        System.out.println();
        
        // String operations
        String testString = "Hello World";
        System.out.println("Original: " + testString);
        System.out.println("Reversed: " + reverseString(testString));
        System.out.println("Is palindrome 'racecar': " + isPalindrome("racecar"));
        System.out.println("Is palindrome 'hello': " + isPalindrome("hello"));
        
        // Array operations
        int[] testArray = {1, 5, 3, 9, 2, 8, 4};
        System.out.println("Array: " + java.util.Arrays.toString(testArray));
        System.out.println("Sum: " + sumArray(testArray, 0));
        System.out.println("Max: " + findMax(testArray, 0));
        
        System.out.println("Recursion demonstration completed!");
    }
}
