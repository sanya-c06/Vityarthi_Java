package edu.ccrm.config;

import java.nio.file.Path;
import java.nio.file.Paths;

/**
 * Application configuration using Singleton pattern
 * Demonstrates Singleton pattern implementation
 */
public class AppConfig {
    private static AppConfig instance;
    private static final Object lock = new Object();
    
    private final Path dataDirectory;
    private final Path backupDirectory;
    private final int maxCreditsPerSemester;
    private final String csvDelimiter;
    private final String dateFormat;
    
    // Private constructor to prevent instantiation
    private AppConfig() {
        this.dataDirectory = Paths.get("data");
        this.backupDirectory = Paths.get("backups");
        this.maxCreditsPerSemester = 18;
        this.csvDelimiter = ",";
        this.dateFormat = "yyyy-MM-dd HH:mm:ss";
        
        // Initialize directories
        initializeDirectories();
    }
    
    /**
     * Get the singleton instance
     * Thread-safe implementation using double-checked locking
     * @return the singleton instance
     */
    public static AppConfig getInstance() {
        if (instance == null) {
            synchronized (lock) {
                if (instance == null) {
                    instance = new AppConfig();
                }
            }
        }
        return instance;
    }
    
    private void initializeDirectories() {
        try {
            if (!dataDirectory.toFile().exists()) {
                dataDirectory.toFile().mkdirs();
            }
            if (!backupDirectory.toFile().exists()) {
                backupDirectory.toFile().mkdirs();
            }
        } catch (Exception e) {
            System.err.println("Error initializing directories: " + e.getMessage());
        }
    }
    
    // Getters for configuration values
    public Path getDataDirectory() {
        return dataDirectory;
    }
    
    public Path getBackupDirectory() {
        return backupDirectory;
    }
    
    public int getMaxCreditsPerSemester() {
        return maxCreditsPerSemester;
    }
    
    public String getCsvDelimiter() {
        return csvDelimiter;
    }
    
    public String getDateFormat() {
        return dateFormat;
    }
    
    /**
     * Reset the singleton instance (for testing purposes)
     */
    public static void resetInstance() {
        synchronized (lock) {
            instance = null;
        }
    }
    
    @Override
    public String toString() {
        return String.format("AppConfig{dataDirectory='%s', backupDirectory='%s', " +
                           "maxCreditsPerSemester=%d, csvDelimiter='%s'}", 
                           dataDirectory, backupDirectory, maxCreditsPerSemester, csvDelimiter);
    }
}
