package edu.ccrm.domain;

import java.util.List;
import java.util.function.Predicate;

/**
 * Generic interface for searchable entities
 * Demonstrates generic interfaces and functional programming
 * @param <T> the type of entity being searched
 */
public interface Searchable<T> {
    
    /**
     * Search entities by a predicate
     * @param predicate the search criteria
     * @return list of matching entities
     */
    List<T> search(Predicate<T> predicate);
    
    /**
     * Search entities by text query
     * @param query the search query
     * @return list of matching entities
     */
    List<T> searchByText(String query);
    
    /**
     * Default method to search by multiple criteria
     * Demonstrates default methods with multiple predicates
     * @param predicates array of search criteria
     * @return list of entities matching all criteria
     */
    default List<T> searchByMultipleCriteria(Predicate<T>... predicates) {
        List<T> results = search(predicates[0]);
        
        for (int i = 1; i < predicates.length; i++) {
            results = results.stream()
                           .filter(predicates[i])
                           .toList();
        }
        
        return results;
    }
    
    /**
     * Default method to get count of matching entities
     * @param predicate the search criteria
     * @return count of matching entities
     */
    default long getSearchCount(Predicate<T> predicate) {
        return search(predicate).size();
    }
}
