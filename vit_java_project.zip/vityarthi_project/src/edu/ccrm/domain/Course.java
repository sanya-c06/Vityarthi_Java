package edu.ccrm.domain;

import edu.ccrm.domain.Semester;
import java.time.LocalDateTime;
import java.util.Objects;

/**
 * Course class representing academic courses
 * Demonstrates encapsulation and Builder pattern
 */
public class Course {
    private String code;
    private String title;
    private int credits;
    private String instructorId;
    private Semester semester;
    private String department;
    private boolean active;
    private LocalDateTime createdDate;
    private LocalDateTime lastModified;

    // Default constructor
    public Course() {
        this.createdDate = LocalDateTime.now();
        this.lastModified = LocalDateTime.now();
        this.active = true;
    }

    // Constructor with parameters
    public Course(String code, String title, int credits, String instructorId, 
                  Semester semester, String department) {
        this();
        this.code = Objects.requireNonNull(code, "Course code cannot be null");
        this.title = Objects.requireNonNull(title, "Course title cannot be null");
        this.credits = credits;
        this.instructorId = instructorId;
        this.semester = Objects.requireNonNull(semester, "Semester cannot be null");
        this.department = Objects.requireNonNull(department, "Department cannot be null");
        validateFields();
    }

    private void validateFields() {
        if (code == null || code.trim().isEmpty()) {
            throw new IllegalArgumentException("Course code is required");
        }
        if (title == null || title.trim().isEmpty()) {
            throw new IllegalArgumentException("Course title is required");
        }
        if (credits <= 0 || credits > 6) {
            throw new IllegalArgumentException("Credits must be between 1 and 6");
        }
        if (department == null || department.trim().isEmpty()) {
            throw new IllegalArgumentException("Department is required");
        }
    }

    public void updateLastModified() {
        this.lastModified = LocalDateTime.now();
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
        updateLastModified();
    }

    // Getters and setters
    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = Objects.requireNonNull(code, "Course code cannot be null");
        updateLastModified();
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = Objects.requireNonNull(title, "Course title cannot be null");
        updateLastModified();
    }

    public int getCredits() {
        return credits;
    }

    public void setCredits(int credits) {
        if (credits <= 0 || credits > 6) {
            throw new IllegalArgumentException("Credits must be between 1 and 6");
        }
        this.credits = credits;
        updateLastModified();
    }

    public String getInstructorId() {
        return instructorId;
    }

    public void setInstructorId(String instructorId) {
        this.instructorId = instructorId;
        updateLastModified();
    }

    public Semester getSemester() {
        return semester;
    }

    public void setSemester(Semester semester) {
        this.semester = Objects.requireNonNull(semester, "Semester cannot be null");
        updateLastModified();
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = Objects.requireNonNull(department, "Department cannot be null");
        updateLastModified();
    }

    public LocalDateTime getCreatedDate() {
        return createdDate;
    }

    public LocalDateTime getLastModified() {
        return lastModified;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Course course = (Course) obj;
        return Objects.equals(code, course.code);
    }

    @Override
    public int hashCode() {
        return Objects.hash(code);
    }

    @Override
    public String toString() {
        return String.format("Course{code='%s', title='%s', credits=%d, " +
                           "instructorId='%s', semester=%s, department='%s', active=%s}", 
                           code, title, credits, instructorId, semester, department, active);
    }

    // Builder pattern implementation
    public static class Builder {
        private String code;
        private String title;
        private int credits;
        private String instructorId;
        private Semester semester;
        private String department;

        public Builder setCode(String code) {
            this.code = code;
            return this;
        }

        public Builder setTitle(String title) {
            this.title = title;
            return this;
        }

        public Builder setCredits(int credits) {
            this.credits = credits;
            return this;
        }

        public Builder setInstructorId(String instructorId) {
            this.instructorId = instructorId;
            return this;
        }

        public Builder setSemester(Semester semester) {
            this.semester = semester;
            return this;
        }

        public Builder setDepartment(String department) {
            this.department = department;
            return this;
        }

        public Course build() {
            return new Course(code, title, credits, instructorId, semester, department);
        }
    }
}
