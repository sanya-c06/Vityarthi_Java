package edu.ccrm.domain;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * Student class extending Person
 * Demonstrates inheritance, encapsulation, and polymorphism
 */
public class Student extends Person implements Persistable {
    private String regNo;
    private List<String> enrolledCourses;
    private StudentStatus status;

    // Default constructor
    public Student() {
        super();
        this.enrolledCourses = new ArrayList<>();
        this.status = StudentStatus.ACTIVE;
    }

    // Constructor with parameters
    public Student(String id, String regNo, String fullName, String email) {
        super(id, fullName, email);
        this.regNo = Objects.requireNonNull(regNo, "Registration number cannot be null");
        this.enrolledCourses = new ArrayList<>();
        this.status = StudentStatus.ACTIVE;
        validateFields();
    }

    @Override
    public String getDisplayInfo() {
        return String.format("Student: %s (%s) - %s", getFullName(), regNo, status);
    }

    @Override
    protected void validateFields() {
        if (regNo == null || regNo.trim().isEmpty()) {
            throw new IllegalArgumentException("Registration number is required");
        }
        if (getFullName() == null || getFullName().trim().isEmpty()) {
            throw new IllegalArgumentException("Full name is required");
        }
        if (getEmail() == null || !getEmail().contains("@")) {
            throw new IllegalArgumentException("Valid email is required");
        }
    }

    // Business logic methods
    public void enrollInCourse(String courseCode) {
        if (status != StudentStatus.ACTIVE) {
            throw new IllegalStateException("Only active students can enroll in courses");
        }
        if (!enrolledCourses.contains(courseCode)) {
            enrolledCourses.add(courseCode);
            updateLastModified();
        }
    }

    public void unenrollFromCourse(String courseCode) {
        if (enrolledCourses.remove(courseCode)) {
            updateLastModified();
        }
    }

    public boolean isEnrolledInCourse(String courseCode) {
        return enrolledCourses.contains(courseCode);
    }

    public int getEnrollmentCount() {
        return enrolledCourses.size();
    }

    // Getters and setters
    public String getRegNo() {
        return regNo;
    }

    public void setRegNo(String regNo) {
        this.regNo = Objects.requireNonNull(regNo, "Registration number cannot be null");
        updateLastModified();
    }

    public List<String> getEnrolledCourses() {
        return new ArrayList<>(enrolledCourses); // Defensive copying
    }

    public void setEnrolledCourses(List<String> enrolledCourses) {
        this.enrolledCourses = new ArrayList<>(Objects.requireNonNull(enrolledCourses, "Enrolled courses cannot be null"));
        updateLastModified();
    }

    public StudentStatus getStatus() {
        return status;
    }

    public void setStatus(StudentStatus status) {
        this.status = Objects.requireNonNull(status, "Status cannot be null");
        updateLastModified();
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        if (!super.equals(obj)) return false;
        Student student = (Student) obj;
        return Objects.equals(regNo, student.regNo);
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), regNo);
    }

    @Override
    public String toString() {
        return String.format("Student{id='%s', regNo='%s', fullName='%s', email='%s', " +
                           "status=%s, enrolledCourses=%d, createdDate=%s}", 
                           getId(), regNo, getFullName(), getEmail(), 
                           status, enrolledCourses.size(), getCreatedDate());
    }

    // Nested enum for student status
    public enum StudentStatus {
        ACTIVE("Active"),
        INACTIVE("Inactive"),
        GRADUATED("Graduated"),
        SUSPENDED("Suspended");

        private final String displayName;

        StudentStatus(String displayName) {
            this.displayName = displayName;
        }

        public String getDisplayName() {
            return displayName;
        }

        @Override
        public String toString() {
            return displayName;
        }
    }
}
