package edu.ccrm.domain;

import java.util.Objects;

/**
 * Instructor class extending Person
 * Demonstrates inheritance and specialization
 */
public class Instructor extends Person implements Persistable {
    private String department;
    private String employeeId;
    private InstructorType type;

    // Default constructor
    public Instructor() {
        super();
        this.type = InstructorType.FULL_TIME;
    }

    // Constructor with parameters
    public Instructor(String id, String employeeId, String fullName, String email, String department) {
        super(id, fullName, email);
        this.employeeId = Objects.requireNonNull(employeeId, "Employee ID cannot be null");
        this.department = Objects.requireNonNull(department, "Department cannot be null");
        this.type = InstructorType.FULL_TIME;
        validateFields();
    }

    @Override
    public String getDisplayInfo() {
        return String.format("Instructor: %s (%s) - %s", getFullName(), employeeId, department);
    }

    @Override
    protected void validateFields() {
        if (employeeId == null || employeeId.trim().isEmpty()) {
            throw new IllegalArgumentException("Employee ID is required");
        }
        if (department == null || department.trim().isEmpty()) {
            throw new IllegalArgumentException("Department is required");
        }
        if (getFullName() == null || getFullName().trim().isEmpty()) {
            throw new IllegalArgumentException("Full name is required");
        }
        if (getEmail() == null || !getEmail().contains("@")) {
            throw new IllegalArgumentException("Valid email is required");
        }
    }

    // Getters and setters
    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = Objects.requireNonNull(department, "Department cannot be null");
        updateLastModified();
    }

    public String getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(String employeeId) {
        this.employeeId = Objects.requireNonNull(employeeId, "Employee ID cannot be null");
        updateLastModified();
    }

    public InstructorType getType() {
        return type;
    }

    public void setType(InstructorType type) {
        this.type = Objects.requireNonNull(type, "Instructor type cannot be null");
        updateLastModified();
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        if (!super.equals(obj)) return false;
        Instructor that = (Instructor) obj;
        return Objects.equals(employeeId, that.employeeId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), employeeId);
    }

    @Override
    public String toString() {
        return String.format("Instructor{id='%s', employeeId='%s', fullName='%s', " +
                           "email='%s', department='%s', type=%s}", 
                           getId(), employeeId, getFullName(), getEmail(), department, type);
    }

    // Nested enum for instructor type
    public enum InstructorType {
        FULL_TIME("Full Time"),
        PART_TIME("Part Time"),
        ADJUNCT("Adjunct"),
        VISITING("Visiting");

        private final String displayName;

        InstructorType(String displayName) {
            this.displayName = displayName;
        }

        public String getDisplayName() {
            return displayName;
        }

        @Override
        public String toString() {
            return displayName;
        }
    }
}
