package edu.ccrm.domain;

import java.time.LocalDateTime;
import java.util.Objects;

/**
 * Abstract base class for Person entities
 * Demonstrates abstraction, encapsulation, and inheritance
 */
public abstract class Person {
    private String id;
    private String fullName;
    private String email;
    private LocalDateTime createdDate;
    private LocalDateTime lastModified;
    private boolean active;

    // Default constructor
    protected Person() {
        this.createdDate = LocalDateTime.now();
        this.lastModified = LocalDateTime.now();
        this.active = true;
    }

    // Constructor with parameters
    protected Person(String id, String fullName, String email) {
        this();
        this.id = Objects.requireNonNull(id, "ID cannot be null");
        this.fullName = Objects.requireNonNull(fullName, "Full name cannot be null");
        this.email = Objects.requireNonNull(email, "Email cannot be null");
    }

    // Abstract method - must be implemented by subclasses
    public abstract String getDisplayInfo();

    // Abstract method for validation - demonstrates abstraction
    protected abstract void validateFields();

    // Concrete methods with polymorphism support
    public void updateLastModified() {
        this.lastModified = LocalDateTime.now();
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
        updateLastModified();
    }

    // Getters and setters with encapsulation
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = Objects.requireNonNull(id, "ID cannot be null");
        updateLastModified();
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = Objects.requireNonNull(fullName, "Full name cannot be null");
        updateLastModified();
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = Objects.requireNonNull(email, "Email cannot be null");
        updateLastModified();
    }

    public LocalDateTime getCreatedDate() {
        return createdDate;
    }

    public LocalDateTime getLastModified() {
        return lastModified;
    }

    // Override equals and hashCode for proper object comparison
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Person person = (Person) obj;
        return Objects.equals(id, person.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    @Override
    public String toString() {
        return String.format("Person{id='%s', fullName='%s', email='%s', active=%s}", 
                           id, fullName, email, active);
    }
}
