package edu.ccrm.domain;

import java.time.LocalDateTime;

/**
 * Interface for entities that can be persisted
 * Demonstrates interface definition and default methods
 */
public interface Persistable {
    
    /**
     * Get the unique identifier
     * @return the ID
     */
    String getId();
    
    /**
     * Get the creation timestamp
     * @return creation date
     */
    LocalDateTime getCreatedDate();
    
    /**
     * Get the last modification timestamp
     * @return last modified date
     */
    LocalDateTime getLastModified();
    
    /**
     * Check if the entity is active
     * @return true if active
     */
    boolean isActive();
    
    /**
     * Default method to get a formatted creation info
     * Demonstrates default methods in interfaces
     * @return formatted string with creation info
     */
    default String getCreationInfo() {
        return String.format("Created: %s, Last Modified: %s", 
                           getCreatedDate(), getLastModified());
    }
    
    /**
     * Default method to check if entity was created recently
     * @param days number of days to check
     * @return true if created within specified days
     */
    default boolean wasCreatedRecently(int days) {
        LocalDateTime cutoff = LocalDateTime.now().minusDays(days);
        return getCreatedDate().isAfter(cutoff);
    }
}
