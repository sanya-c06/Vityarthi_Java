package edu.ccrm.domain;

import edu.ccrm.domain.Grade;
import edu.ccrm.domain.Semester;
import java.time.LocalDateTime;
import java.util.Objects;

/**
 * Enrollment class representing student-course enrollment
 * Demonstrates composition and encapsulation
 */
public class Enrollment {
    private String id;
    private String studentId;
    private String courseCode;
    private Semester semester;
    private int year;
    private LocalDateTime enrollmentDate;
    private Grade grade;
    private boolean active;

    // Default constructor
    public Enrollment() {
        this.enrollmentDate = LocalDateTime.now();
        this.active = true;
    }

    // Constructor with parameters
    public Enrollment(String id, String studentId, String courseCode, Semester semester, int year) {
        this();
        this.id = Objects.requireNonNull(id, "Enrollment ID cannot be null");
        this.studentId = Objects.requireNonNull(studentId, "Student ID cannot be null");
        this.courseCode = Objects.requireNonNull(courseCode, "Course code cannot be null");
        this.semester = Objects.requireNonNull(semester, "Semester cannot be null");
        this.year = year;
        validateFields();
    }

    private void validateFields() {
        if (id == null || id.trim().isEmpty()) {
            throw new IllegalArgumentException("Enrollment ID is required");
        }
        if (studentId == null || studentId.trim().isEmpty()) {
            throw new IllegalArgumentException("Student ID is required");
        }
        if (courseCode == null || courseCode.trim().isEmpty()) {
            throw new IllegalArgumentException("Course code is required");
        }
        if (year < 2020 || year > 2030) {
            throw new IllegalArgumentException("Year must be between 2020 and 2030");
        }
    }

    // Business logic methods
    public void recordGrade(Grade grade) {
        if (!active) {
            throw new IllegalStateException("Cannot record grade for inactive enrollment");
        }
        this.grade = Objects.requireNonNull(grade, "Grade cannot be null");
    }

    public boolean hasGrade() {
        return grade != null;
    }

    public boolean isPassing() {
        return hasGrade() && grade.isPassing();
    }

    public void deactivate() {
        this.active = false;
    }

    // Getters and setters
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = Objects.requireNonNull(id, "Enrollment ID cannot be null");
    }

    public String getStudentId() {
        return studentId;
    }

    public void setStudentId(String studentId) {
        this.studentId = Objects.requireNonNull(studentId, "Student ID cannot be null");
    }

    public String getCourseCode() {
        return courseCode;
    }

    public void setCourseCode(String courseCode) {
        this.courseCode = Objects.requireNonNull(courseCode, "Course code cannot be null");
    }

    public Semester getSemester() {
        return semester;
    }

    public void setSemester(Semester semester) {
        this.semester = Objects.requireNonNull(semester, "Semester cannot be null");
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        if (year < 2020 || year > 2030) {
            throw new IllegalArgumentException("Year must be between 2020 and 2030");
        }
        this.year = year;
    }

    public LocalDateTime getEnrollmentDate() {
        return enrollmentDate;
    }

    public void setEnrollmentDate(LocalDateTime enrollmentDate) {
        this.enrollmentDate = Objects.requireNonNull(enrollmentDate, "Enrollment date cannot be null");
    }

    public Grade getGrade() {
        return grade;
    }

    public void setGrade(Grade grade) {
        this.grade = grade;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Enrollment that = (Enrollment) obj;
        return Objects.equals(id, that.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    @Override
    public String toString() {
        return String.format("Enrollment{id='%s', studentId='%s', courseCode='%s', " +
                           "semester=%s, year=%d, grade=%s, active=%s}", 
                           id, studentId, courseCode, semester, year, grade, active);
    }
}
