package edu.ccrm.domain;

/**
 * Enum representing letter grades with grade points
 * Demonstrates enum with constructor, fields, and business logic
 */
public enum Grade {
    S("S", 10.0, "Excellent"),
    A("A", 9.0, "Very Good"),
    B("B", 8.0, "Good"),
    C("C", 7.0, "Average"),
    D("D", 6.0, "Below Average"),
    E("E", 5.0, "Poor"),
    F("F", 0.0, "Fail");

    private final String letter;
    private final double gradePoint;
    private final String description;

    // Constructor for enum
    Grade(String letter, double gradePoint, String description) {
        this.letter = letter;
        this.gradePoint = gradePoint;
        this.description = description;
    }

    public String getLetter() {
        return letter;
    }

    public double getGradePoint() {
        return gradePoint;
    }

    public String getDescription() {
        return description;
    }

    // Business logic method to determine if grade is passing
    public boolean isPassing() {
        return this != F;
    }

    // Static method to get grade from percentage
    public static Grade fromPercentage(double percentage) {
        if (percentage >= 90) return S;
        if (percentage >= 80) return A;
        if (percentage >= 70) return B;
        if (percentage >= 60) return C;
        if (percentage >= 50) return D;
        if (percentage >= 40) return E;
        return F;
    }

    // Static method to get grade from grade point
    public static Grade fromGradePoint(double gradePoint) {
        for (Grade grade : values()) {
            if (Math.abs(grade.gradePoint - gradePoint) < 0.1) {
                return grade;
            }
        }
        throw new IllegalArgumentException("Invalid grade point: " + gradePoint);
    }

    @Override
    public String toString() {
        return letter + " (" + gradePoint + ")";
    }
}
